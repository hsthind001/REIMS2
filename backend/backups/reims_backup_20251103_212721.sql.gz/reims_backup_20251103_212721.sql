--
-- PostgreSQL database dump
--

\restrict vxVE1mlGVbPtfqdzGN9jKQPFB2FskKJTVnyYyf3sGR6BnYwBhoClK7vDdWDqwlV

-- Dumped from database version 17.6 (Debian 17.6-2.pgdg13+1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-2.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_trail; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.audit_trail (
    id integer NOT NULL,
    table_name character varying(100) NOT NULL,
    record_id integer NOT NULL,
    action character varying(50) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    changed_by integer,
    changed_at timestamp with time zone DEFAULT now(),
    reason text,
    ip_address inet
);


ALTER TABLE public.audit_trail OWNER TO reims;

--
-- Name: audit_trail_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.audit_trail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_trail_id_seq OWNER TO reims;

--
-- Name: audit_trail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.audit_trail_id_seq OWNED BY public.audit_trail.id;


--
-- Name: balance_sheet_data; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.balance_sheet_data (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    upload_id integer,
    account_id integer NOT NULL,
    account_code character varying(50) NOT NULL,
    account_name character varying(255) NOT NULL,
    amount numeric(15,2) NOT NULL,
    is_debit boolean,
    is_calculated boolean,
    parent_account_code character varying(50),
    extraction_confidence numeric(5,2),
    needs_review boolean,
    reviewed boolean,
    reviewed_by integer,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.balance_sheet_data OWNER TO reims;

--
-- Name: balance_sheet_data_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.balance_sheet_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.balance_sheet_data_id_seq OWNER TO reims;

--
-- Name: balance_sheet_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.balance_sheet_data_id_seq OWNED BY public.balance_sheet_data.id;


--
-- Name: cash_flow_data; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.cash_flow_data (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    upload_id integer,
    account_id integer NOT NULL,
    account_code character varying(50) NOT NULL,
    account_name character varying(255) NOT NULL,
    period_amount numeric(15,2) NOT NULL,
    ytd_amount numeric(15,2),
    period_percentage numeric(5,2),
    ytd_percentage numeric(5,2),
    cash_flow_category character varying(50),
    is_inflow boolean,
    is_calculated boolean,
    parent_account_code character varying(50),
    extraction_confidence numeric(5,2),
    needs_review boolean,
    reviewed boolean,
    reviewed_by integer,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.cash_flow_data OWNER TO reims;

--
-- Name: cash_flow_data_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.cash_flow_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cash_flow_data_id_seq OWNER TO reims;

--
-- Name: cash_flow_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.cash_flow_data_id_seq OWNED BY public.cash_flow_data.id;


--
-- Name: chart_of_accounts; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.chart_of_accounts (
    id integer NOT NULL,
    account_code character varying(50) NOT NULL,
    account_name character varying(255) NOT NULL,
    account_type character varying(50) NOT NULL,
    category character varying(100),
    subcategory character varying(100),
    parent_account_code character varying(50),
    document_types text[],
    is_calculated boolean,
    calculation_formula text,
    display_order integer,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.chart_of_accounts OWNER TO reims;

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.chart_of_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chart_of_accounts_id_seq OWNER TO reims;

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.chart_of_accounts_id_seq OWNED BY public.chart_of_accounts.id;


--
-- Name: document_uploads; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.document_uploads (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    document_type character varying(50) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(500),
    file_hash character varying(64),
    file_size_bytes bigint,
    upload_date timestamp with time zone DEFAULT now(),
    uploaded_by integer,
    extraction_status character varying(50),
    extraction_started_at timestamp with time zone,
    extraction_completed_at timestamp with time zone,
    extraction_id integer,
    version integer,
    is_active boolean,
    notes text
);


ALTER TABLE public.document_uploads OWNER TO reims;

--
-- Name: document_uploads_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.document_uploads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.document_uploads_id_seq OWNER TO reims;

--
-- Name: document_uploads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.document_uploads_id_seq OWNED BY public.document_uploads.id;


--
-- Name: extraction_logs; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.extraction_logs (
    id integer NOT NULL,
    filename character varying NOT NULL,
    file_size integer,
    file_hash character varying,
    document_type character varying,
    total_pages integer,
    strategy_used character varying,
    engines_used json,
    primary_engine character varying,
    confidence_score double precision,
    quality_level character varying,
    passed_checks integer,
    total_checks integer,
    processing_time_seconds double precision,
    extraction_timestamp timestamp with time zone DEFAULT now(),
    validation_issues json,
    validation_warnings json,
    recommendations json,
    extracted_text text,
    text_preview character varying(500),
    total_words integer,
    total_chars integer,
    tables_found integer,
    images_found integer,
    needs_review boolean,
    reviewed boolean,
    reviewed_by character varying,
    reviewed_at timestamp with time zone,
    review_notes text,
    custom_metadata json,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.extraction_logs OWNER TO reims;

--
-- Name: extraction_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.extraction_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.extraction_logs_id_seq OWNER TO reims;

--
-- Name: extraction_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.extraction_logs_id_seq OWNED BY public.extraction_logs.id;


--
-- Name: extraction_templates; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.extraction_templates (
    id integer NOT NULL,
    template_name character varying(100) NOT NULL,
    document_type character varying(50) NOT NULL,
    template_structure jsonb,
    keywords text[],
    extraction_rules jsonb,
    is_default boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.extraction_templates OWNER TO reims;

--
-- Name: extraction_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.extraction_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.extraction_templates_id_seq OWNER TO reims;

--
-- Name: extraction_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.extraction_templates_id_seq OWNED BY public.extraction_templates.id;


--
-- Name: financial_metrics; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.financial_metrics (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    total_assets numeric(15,2),
    total_liabilities numeric(15,2),
    total_equity numeric(15,2),
    current_ratio numeric(10,4),
    debt_to_equity_ratio numeric(10,4),
    total_revenue numeric(15,2),
    total_expenses numeric(15,2),
    net_operating_income numeric(15,2),
    net_income numeric(15,2),
    operating_margin numeric(10,4),
    profit_margin numeric(10,4),
    operating_cash_flow numeric(15,2),
    investing_cash_flow numeric(15,2),
    financing_cash_flow numeric(15,2),
    net_cash_flow numeric(15,2),
    beginning_cash_balance numeric(15,2),
    ending_cash_balance numeric(15,2),
    total_units integer,
    occupied_units integer,
    vacant_units integer,
    occupancy_rate numeric(5,2),
    total_leasable_sqft numeric(12,2),
    occupied_sqft numeric(12,2),
    total_monthly_rent numeric(12,2),
    total_annual_rent numeric(12,2),
    avg_rent_per_sqft numeric(10,4),
    noi_per_sqft numeric(10,4),
    revenue_per_sqft numeric(10,4),
    expense_ratio numeric(5,2),
    calculated_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.financial_metrics OWNER TO reims;

--
-- Name: financial_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.financial_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.financial_metrics_id_seq OWNER TO reims;

--
-- Name: financial_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.financial_metrics_id_seq OWNED BY public.financial_metrics.id;


--
-- Name: financial_periods; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.financial_periods (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_year integer NOT NULL,
    period_month integer NOT NULL,
    period_start_date date NOT NULL,
    period_end_date date NOT NULL,
    fiscal_year integer,
    fiscal_quarter integer,
    is_closed boolean,
    closed_date timestamp with time zone,
    closed_by integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.financial_periods OWNER TO reims;

--
-- Name: financial_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.financial_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.financial_periods_id_seq OWNER TO reims;

--
-- Name: financial_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.financial_periods_id_seq OWNED BY public.financial_periods.id;


--
-- Name: income_statement_data; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.income_statement_data (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    upload_id integer,
    account_id integer NOT NULL,
    account_code character varying(50) NOT NULL,
    account_name character varying(255) NOT NULL,
    period_amount numeric(15,2) NOT NULL,
    ytd_amount numeric(15,2),
    period_percentage numeric(5,2),
    ytd_percentage numeric(5,2),
    is_income boolean,
    is_calculated boolean,
    parent_account_code character varying(50),
    extraction_confidence numeric(5,2),
    needs_review boolean,
    reviewed boolean,
    reviewed_by integer,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.income_statement_data OWNER TO reims;

--
-- Name: income_statement_data_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.income_statement_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.income_statement_data_id_seq OWNER TO reims;

--
-- Name: income_statement_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.income_statement_data_id_seq OWNED BY public.income_statement_data.id;


--
-- Name: properties; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.properties (
    id integer NOT NULL,
    property_code character varying(50) NOT NULL,
    property_name character varying(255) NOT NULL,
    property_type character varying(50),
    address text,
    city character varying(100),
    state character varying(50),
    zip_code character varying(20),
    country character varying(50),
    total_area_sqft numeric(12,2),
    acquisition_date date,
    ownership_structure character varying(100),
    status character varying(50),
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by integer
);


ALTER TABLE public.properties OWNER TO reims;

--
-- Name: properties_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.properties_id_seq OWNER TO reims;

--
-- Name: properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.properties_id_seq OWNED BY public.properties.id;


--
-- Name: rent_roll_data; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.rent_roll_data (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    upload_id integer,
    unit_number character varying(50) NOT NULL,
    tenant_name character varying(255) NOT NULL,
    tenant_code character varying(50),
    lease_type character varying(50),
    lease_start_date date,
    lease_end_date date,
    lease_term_months integer,
    remaining_lease_years numeric(5,2),
    unit_area_sqft numeric(10,2),
    monthly_rent numeric(12,2),
    monthly_rent_per_sqft numeric(10,4),
    annual_rent numeric(12,2),
    annual_rent_per_sqft numeric(10,4),
    gross_rent numeric(12,2),
    security_deposit numeric(12,2),
    loc_amount numeric(12,2),
    annual_cam_reimbursement numeric(12,2),
    annual_tax_reimbursement numeric(12,2),
    annual_insurance_reimbursement numeric(12,2),
    occupancy_status character varying(50),
    lease_status character varying(50),
    extraction_confidence numeric(5,2),
    needs_review boolean,
    reviewed boolean,
    reviewed_by integer,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.rent_roll_data OWNER TO reims;

--
-- Name: rent_roll_data_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.rent_roll_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rent_roll_data_id_seq OWNER TO reims;

--
-- Name: rent_roll_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.rent_roll_data_id_seq OWNED BY public.rent_roll_data.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying NOT NULL,
    username character varying NOT NULL,
    hashed_password character varying NOT NULL,
    is_active boolean,
    is_superuser boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO reims;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO reims;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: v_extraction_quality_dashboard; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_extraction_quality_dashboard AS
 SELECT p.property_code,
    p.property_name,
    fp.period_year,
    fp.period_month,
    du.document_type,
    du.file_name,
    du.extraction_status,
    el.confidence_score,
    el.quality_level,
    el.passed_checks,
    el.total_checks,
    el.needs_review,
    du.upload_date,
    du.extraction_completed_at,
    EXTRACT(epoch FROM (du.extraction_completed_at - du.extraction_started_at)) AS processing_seconds
   FROM (((public.document_uploads du
     JOIN public.properties p ON ((du.property_id = p.id)))
     JOIN public.financial_periods fp ON ((du.period_id = fp.id)))
     LEFT JOIN public.extraction_logs el ON ((du.extraction_id = el.id)))
  WHERE (du.is_active = true)
  ORDER BY du.upload_date DESC;


ALTER VIEW public.v_extraction_quality_dashboard OWNER TO reims;

--
-- Name: v_monthly_comparison; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_monthly_comparison AS
 SELECT p.property_code,
    p.property_name,
    isd.account_code,
    isd.account_name,
    fp.period_year,
    fp.period_month,
    isd.period_amount AS current_month,
    lag(isd.period_amount) OVER (PARTITION BY isd.property_id, isd.account_code ORDER BY fp.period_year, fp.period_month) AS previous_month,
    (isd.period_amount - lag(isd.period_amount) OVER (PARTITION BY isd.property_id, isd.account_code ORDER BY fp.period_year, fp.period_month)) AS month_variance,
    round((((isd.period_amount - lag(isd.period_amount) OVER (PARTITION BY isd.property_id, isd.account_code ORDER BY fp.period_year, fp.period_month)) / NULLIF(lag(isd.period_amount) OVER (PARTITION BY isd.property_id, isd.account_code ORDER BY fp.period_year, fp.period_month), (0)::numeric)) * (100)::numeric), 2) AS variance_percentage,
    isd.ytd_amount,
    isd.is_income
   FROM ((public.income_statement_data isd
     JOIN public.financial_periods fp ON ((isd.period_id = fp.id)))
     JOIN public.properties p ON ((isd.property_id = p.id)))
  WHERE ((p.status)::text = 'active'::text)
  ORDER BY p.property_code, fp.period_year DESC, fp.period_month DESC, isd.account_code;


ALTER VIEW public.v_monthly_comparison OWNER TO reims;

--
-- Name: v_multi_property_comparison; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_multi_property_comparison AS
 SELECT fp.period_year,
    fp.period_month,
    p.property_code,
    p.property_name,
    p.property_type,
    p.total_area_sqft,
    fm.total_revenue,
    fm.net_operating_income,
    fm.net_income,
    fm.occupancy_rate,
    fm.noi_per_sqft,
    fm.revenue_per_sqft,
    fm.expense_ratio,
    fm.operating_margin,
    rank() OVER (PARTITION BY fp.period_year, fp.period_month ORDER BY fm.net_operating_income DESC) AS noi_rank,
    rank() OVER (PARTITION BY fp.period_year, fp.period_month ORDER BY fm.occupancy_rate DESC) AS occupancy_rank
   FROM ((public.properties p
     JOIN public.financial_periods fp ON ((p.id = fp.property_id)))
     LEFT JOIN public.financial_metrics fm ON ((fp.id = fm.period_id)))
  WHERE ((p.status)::text = 'active'::text)
  ORDER BY fp.period_year DESC, fp.period_month DESC, fm.net_operating_income DESC;


ALTER VIEW public.v_multi_property_comparison OWNER TO reims;

--
-- Name: v_property_financial_summary; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_property_financial_summary AS
 SELECT p.property_code,
    p.property_name,
    p.property_type,
    p.city,
    p.state,
    fp.period_year,
    fp.period_month,
    fp.period_start_date,
    fp.period_end_date,
    fm.total_assets,
    fm.total_liabilities,
    fm.total_equity,
    fm.current_ratio,
    fm.debt_to_equity_ratio,
    fm.total_revenue,
    fm.total_expenses,
    fm.net_operating_income,
    fm.net_income,
    fm.operating_margin,
    fm.profit_margin,
    fm.operating_cash_flow,
    fm.investing_cash_flow,
    fm.financing_cash_flow,
    fm.net_cash_flow,
    fm.ending_cash_balance,
    fm.total_units,
    fm.occupied_units,
    fm.vacant_units,
    fm.occupancy_rate,
    fm.total_annual_rent,
    fm.avg_rent_per_sqft,
    fm.noi_per_sqft,
    fm.revenue_per_sqft,
    fm.expense_ratio,
    fm.calculated_at
   FROM ((public.properties p
     JOIN public.financial_periods fp ON ((p.id = fp.property_id)))
     LEFT JOIN public.financial_metrics fm ON ((fp.id = fm.period_id)))
  WHERE ((p.status)::text = 'active'::text)
  ORDER BY p.property_code, fp.period_year DESC, fp.period_month DESC;


ALTER VIEW public.v_property_financial_summary OWNER TO reims;

--
-- Name: validation_results; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.validation_results (
    id integer NOT NULL,
    upload_id integer NOT NULL,
    rule_id integer NOT NULL,
    passed boolean NOT NULL,
    expected_value numeric(15,2),
    actual_value numeric(15,2),
    difference numeric(15,2),
    difference_percentage numeric(10,4),
    error_message text,
    severity character varying(20),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.validation_results OWNER TO reims;

--
-- Name: validation_rules; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.validation_rules (
    id integer NOT NULL,
    rule_name character varying(100) NOT NULL,
    rule_description text,
    document_type character varying(50) NOT NULL,
    rule_type character varying(50) NOT NULL,
    rule_formula text,
    error_message text,
    severity character varying(20),
    is_active boolean,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.validation_rules OWNER TO reims;

--
-- Name: v_validation_issues; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_validation_issues AS
 SELECT p.property_code,
    p.property_name,
    fp.period_year,
    fp.period_month,
    du.document_type,
    vr.rule_name,
    vr.rule_description,
    vres.passed,
    vres.expected_value,
    vres.actual_value,
    vres.difference,
    vres.difference_percentage,
    vres.error_message,
    vres.severity,
    vres.created_at
   FROM ((((public.validation_results vres
     JOIN public.validation_rules vr ON ((vres.rule_id = vr.id)))
     JOIN public.document_uploads du ON ((vres.upload_id = du.id)))
     JOIN public.properties p ON ((du.property_id = p.id)))
     JOIN public.financial_periods fp ON ((du.period_id = fp.id)))
  WHERE ((vres.passed = false) AND (vr.is_active = true))
  ORDER BY vres.severity DESC, vres.created_at DESC;


ALTER VIEW public.v_validation_issues OWNER TO reims;

--
-- Name: v_ytd_rollup; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_ytd_rollup AS
 SELECT p.property_code,
    p.property_name,
    fp.fiscal_year,
    sum(fm.total_revenue) AS ytd_revenue,
    sum(fm.total_expenses) AS ytd_expenses,
    sum(fm.net_operating_income) AS ytd_noi,
    sum(fm.net_income) AS ytd_net_income,
    avg(fm.occupancy_rate) AS avg_occupancy_rate,
    max(fm.ending_cash_balance) AS latest_cash_balance,
    count(DISTINCT fp.id) AS periods_reported
   FROM ((public.properties p
     JOIN public.financial_periods fp ON ((p.id = fp.property_id)))
     LEFT JOIN public.financial_metrics fm ON ((fp.id = fm.period_id)))
  WHERE ((p.status)::text = 'active'::text)
  GROUP BY p.property_code, p.property_name, fp.fiscal_year
  ORDER BY p.property_code, fp.fiscal_year DESC;


ALTER VIEW public.v_ytd_rollup OWNER TO reims;

--
-- Name: validation_results_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.validation_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.validation_results_id_seq OWNER TO reims;

--
-- Name: validation_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.validation_results_id_seq OWNED BY public.validation_results.id;


--
-- Name: validation_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.validation_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.validation_rules_id_seq OWNER TO reims;

--
-- Name: validation_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.validation_rules_id_seq OWNED BY public.validation_rules.id;


--
-- Name: audit_trail id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.audit_trail ALTER COLUMN id SET DEFAULT nextval('public.audit_trail_id_seq'::regclass);


--
-- Name: balance_sheet_data id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data ALTER COLUMN id SET DEFAULT nextval('public.balance_sheet_data_id_seq'::regclass);


--
-- Name: cash_flow_data id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data ALTER COLUMN id SET DEFAULT nextval('public.cash_flow_data_id_seq'::regclass);


--
-- Name: chart_of_accounts id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.chart_of_accounts ALTER COLUMN id SET DEFAULT nextval('public.chart_of_accounts_id_seq'::regclass);


--
-- Name: document_uploads id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads ALTER COLUMN id SET DEFAULT nextval('public.document_uploads_id_seq'::regclass);


--
-- Name: extraction_logs id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.extraction_logs ALTER COLUMN id SET DEFAULT nextval('public.extraction_logs_id_seq'::regclass);


--
-- Name: extraction_templates id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.extraction_templates ALTER COLUMN id SET DEFAULT nextval('public.extraction_templates_id_seq'::regclass);


--
-- Name: financial_metrics id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_metrics ALTER COLUMN id SET DEFAULT nextval('public.financial_metrics_id_seq'::regclass);


--
-- Name: financial_periods id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_periods ALTER COLUMN id SET DEFAULT nextval('public.financial_periods_id_seq'::regclass);


--
-- Name: income_statement_data id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data ALTER COLUMN id SET DEFAULT nextval('public.income_statement_data_id_seq'::regclass);


--
-- Name: properties id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.properties ALTER COLUMN id SET DEFAULT nextval('public.properties_id_seq'::regclass);


--
-- Name: rent_roll_data id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data ALTER COLUMN id SET DEFAULT nextval('public.rent_roll_data_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: validation_results id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_results ALTER COLUMN id SET DEFAULT nextval('public.validation_results_id_seq'::regclass);


--
-- Name: validation_rules id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_rules ALTER COLUMN id SET DEFAULT nextval('public.validation_rules_id_seq'::regclass);


--
-- Data for Name: audit_trail; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.audit_trail (id, table_name, record_id, action, old_values, new_values, changed_fields, changed_by, changed_at, reason, ip_address) FROM stdin;
\.


--
-- Data for Name: balance_sheet_data; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.balance_sheet_data (id, property_id, period_id, upload_id, account_id, account_code, account_name, amount, is_debit, is_calculated, parent_account_code, extraction_confidence, needs_review, reviewed, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cash_flow_data; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.cash_flow_data (id, property_id, period_id, upload_id, account_id, account_code, account_name, period_amount, ytd_amount, period_percentage, ytd_percentage, cash_flow_category, is_inflow, is_calculated, parent_account_code, extraction_confidence, needs_review, reviewed, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.chart_of_accounts (id, account_code, account_name, account_type, category, subcategory, parent_account_code, document_types, is_calculated, calculation_formula, display_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_uploads; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.document_uploads (id, property_id, period_id, document_type, file_name, file_path, file_hash, file_size_bytes, upload_date, uploaded_by, extraction_status, extraction_started_at, extraction_completed_at, extraction_id, version, is_active, notes) FROM stdin;
1	2	1	balance_sheet	ESP 2023 Balance Sheet.pdf	ESP001/2023/12/balance_sheet_20251104_031259.pdf	a4050400f386bd451cf1a8fd901f9f67	3585	2025-11-04 03:12:59.786183+00	\N	pending	\N	\N	\N	1	t	\N
2	2	1	cash_flow	ESP 2023 Cash Flow Statement.pdf	ESP001/2023/12/cash_flow_20251104_031502.pdf	a0ef1ce18c3493be41cbbeb27a350b14	25545	2025-11-04 03:15:02.447878+00	\N	pending	\N	\N	\N	1	t	\N
3	2	1	income_statement	ESP 2023 Income Statement.pdf	ESP001/2023/12/income_statement_20251104_031704.pdf	209d5e2c237167da7eea1fe635cc011e	8684	2025-11-04 03:17:04.48927+00	\N	pending	\N	\N	\N	1	t	\N
4	2	2	balance_sheet	ESP 2024 Balance Sheet.pdf	ESP001/2024/12/balance_sheet_20251104_031906.pdf	15a5bbadb72da091f20e00d6ec3cf1ec	8358	2025-11-04 03:19:06.449345+00	\N	pending	\N	\N	\N	1	t	\N
5	2	2	cash_flow	ESP 2024 Cash Flow Statement.pdf	ESP001/2024/12/cash_flow_20251104_032108.pdf	6072cbde347533acff38a27e5341d929	25569	2025-11-04 03:21:08.47514+00	\N	pending	\N	\N	\N	1	t	\N
6	2	2	income_statement	ESP 2024 Income Statement.pdf	ESP001/2024/12/income_statement_20251104_032251.pdf	5bd3dc53da90ec4dc46f4dea1fc6e626	14007	2025-11-04 03:22:51.537996+00	\N	pending	\N	\N	\N	1	t	\N
7	2	3	rent_roll	ESP Roll April 2025.pdf	ESP001/2025/04/rent_roll_20251104_032252.pdf	a626acd787d1765b817a025a9722dbe3	41380	2025-11-04 03:22:52.109569+00	\N	pending	\N	\N	\N	1	t	\N
8	3	4	balance_sheet	Hammond Aire 2023 Balance Sheet.pdf	HMND001/2023/12/balance_sheet_20251104_032252.pdf	d2a57acc42ae11e3d827351c5a8235d1	3568	2025-11-04 03:22:52.328977+00	\N	pending	\N	\N	\N	1	t	\N
9	3	4	income_statement	Hammond Aire 2023 Income Statement.pdf	HMND001/2023/12/income_statement_20251104_032252.pdf	bf97a38dbc6cd6c0d0f56b3debf9311d	8812	2025-11-04 03:22:52.539929+00	\N	pending	\N	\N	\N	1	t	\N
10	3	4	cash_flow	Hammond Aire 2023 Cash Flow Statement.pdf	HMND001/2023/12/cash_flow_20251104_032252.pdf	9094bac01d2fa1c402dd79f546824d4a	25513	2025-11-04 03:22:52.789062+00	\N	pending	\N	\N	\N	1	t	\N
11	3	5	balance_sheet	Hammond Aire2024 Balance Sheet.pdf	HMND001/2024/12/balance_sheet_20251104_032253.pdf	ad68ed4a7127d403a01c493bfa3287b3	8387	2025-11-04 03:22:53.036547+00	\N	pending	\N	\N	\N	1	t	\N
12	3	6	rent_roll	Hammond Rent Roll April 2025.pdf	HMND001/2025/04/rent_roll_20251104_032253.pdf	933ef4c2a07ec2bb7e8b800098f00f14	60419	2025-11-04 03:22:53.455818+00	\N	pending	\N	\N	\N	1	t	\N
13	4	7	balance_sheet	TCSH 2023 Balance Sheet.pdf	TCSH001/2023/12/balance_sheet_20251104_032253.pdf	4decd7e9779c9969fe5631c083dea106	3686	2025-11-04 03:22:53.744155+00	\N	pending	\N	\N	\N	1	t	\N
14	4	7	income_statement	TCSH 2023 Income Statement.pdf	TCSH001/2023/12/income_statement_20251104_032254.pdf	ff8d69acf870d7cf03c5ac36c801c6d3	8207	2025-11-04 03:22:54.041775+00	\N	pending	\N	\N	\N	1	t	\N
15	4	7	cash_flow	TCSH 2023 Cash FLow Statement.pdf	TCSH001/2023/12/cash_flow_20251104_032254.pdf	5b311264b8520d71e788d7ec09a8c511	25203	2025-11-04 03:22:54.241152+00	\N	pending	\N	\N	\N	1	t	\N
16	4	8	balance_sheet	TCSH 2024 Balance Sheet.pdf	TCSH001/2024/12/balance_sheet_20251104_032254.pdf	a8203d57fe9d34fc1a13e7de88105e10	3764	2025-11-04 03:22:54.535014+00	\N	pending	\N	\N	\N	1	t	\N
17	4	8	income_statement	TCSH 2024 Income Statement.pdf	TCSH001/2024/12/income_statement_20251104_032254.pdf	7234d687c3ccebe38b07d38e980df3e2	7599	2025-11-04 03:22:54.696322+00	\N	pending	\N	\N	\N	1	t	\N
18	4	8	cash_flow	TCSH 2024 Cash Flow Statement.pdf	TCSH001/2024/12/cash_flow_20251104_032254.pdf	95b42632da1f0ddedd86eab7ae8d5c11	25388	2025-11-04 03:22:54.944407+00	\N	pending	\N	\N	\N	1	t	\N
19	4	9	rent_roll	TCSH Rent Roll April 2025.pdf	TCSH001/2025/04/rent_roll_20251104_032255.pdf	cff11b662d18b8b504554e22bc691276	61660	2025-11-04 03:22:55.285312+00	\N	pending	\N	\N	\N	1	t	\N
20	5	10	balance_sheet	Wendover Commons 2023 Balance Sheet.pdf	WEND001/2023/12/balance_sheet_20251104_032255.pdf	f90c162b4fc7683861d96a526c8db467	3359	2025-11-04 03:22:55.606707+00	\N	pending	\N	\N	\N	1	t	\N
21	5	10	income_statement	Wendover Commons 2023 Income Statement.pdf	WEND001/2023/12/income_statement_20251104_032255.pdf	15696323808739bfaf170e959c745690	7785	2025-11-04 03:22:55.82238+00	\N	pending	\N	\N	\N	1	t	\N
22	5	10	cash_flow	Wendover Commons 2023 Cash Flow Statement.pdf	WEND001/2023/12/cash_flow_20251104_032256.pdf	4c16a81f10f4a901f816315eedc41161	25018	2025-11-04 03:22:56.047246+00	\N	pending	\N	\N	\N	1	t	\N
23	5	11	balance_sheet	Wendover Commons 2024 Balance Sheet.pdf	WEND001/2024/12/balance_sheet_20251104_032256.pdf	a1bb225e32356b98133686ab6b84a2d5	3595	2025-11-04 03:22:56.401247+00	\N	pending	\N	\N	\N	1	t	\N
24	5	11	income_statement	Wendover Commons 2024 Income Statement.pdf	WEND001/2024/12/income_statement_20251104_032256.pdf	6268cba12fab48ad7d9112158be62688	7531	2025-11-04 03:22:56.621295+00	\N	pending	\N	\N	\N	1	t	\N
25	5	11	cash_flow	Wendover Commons 2024 Cash Flow Statement.pdf	WEND001/2024/12/cash_flow_20251104_032256.pdf	f8ce93aca4295d1c052db5354ca1869e	25263	2025-11-04 03:22:56.844148+00	\N	pending	\N	\N	\N	1	t	\N
26	5	12	rent_roll	Wendover Rent Roll April 2025.pdf	WEND001/2025/04/rent_roll_20251104_032257.pdf	5e264c38b7c52ef67eeac3658f0d69e6	29636	2025-11-04 03:22:57.202837+00	\N	pending	\N	\N	\N	1	t	\N
27	3	5	income_statement	Hammond Aire 2024 Income Statement.pdf	HMND001/2024/12/income_statement_20251104_032325.pdf	270e29c788951852b4d1efd93b533ab5	14164	2025-11-04 03:23:25.539064+00	\N	pending	\N	\N	\N	1	t	\N
28	3	5	cash_flow	Hammond Aire 2024 Cash Flow Statement.pdf	HMND001/2024/12/cash_flow_20251104_032332.pdf	26070f40babf1dd322391c3ccaa20562	25785	2025-11-04 03:23:32.959392+00	\N	pending	\N	\N	\N	1	t	\N
\.


--
-- Data for Name: extraction_logs; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.extraction_logs (id, filename, file_size, file_hash, document_type, total_pages, strategy_used, engines_used, primary_engine, confidence_score, quality_level, passed_checks, total_checks, processing_time_seconds, extraction_timestamp, validation_issues, validation_warnings, recommendations, extracted_text, text_preview, total_words, total_chars, tables_found, images_found, needs_review, reviewed, reviewed_by, reviewed_at, review_notes, custom_metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: extraction_templates; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.extraction_templates (id, template_name, document_type, template_structure, keywords, extraction_rules, is_default, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: financial_metrics; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.financial_metrics (id, property_id, period_id, total_assets, total_liabilities, total_equity, current_ratio, debt_to_equity_ratio, total_revenue, total_expenses, net_operating_income, net_income, operating_margin, profit_margin, operating_cash_flow, investing_cash_flow, financing_cash_flow, net_cash_flow, beginning_cash_balance, ending_cash_balance, total_units, occupied_units, vacant_units, occupancy_rate, total_leasable_sqft, occupied_sqft, total_monthly_rent, total_annual_rent, avg_rent_per_sqft, noi_per_sqft, revenue_per_sqft, expense_ratio, calculated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: financial_periods; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.financial_periods (id, property_id, period_year, period_month, period_start_date, period_end_date, fiscal_year, fiscal_quarter, is_closed, closed_date, closed_by, created_at) FROM stdin;
1	2	2023	12	2023-12-01	2023-12-31	2023	4	f	\N	\N	2025-11-04 03:12:59.698466+00
2	2	2024	12	2024-12-01	2024-12-31	2024	4	f	\N	\N	2025-11-04 03:19:06.420654+00
3	2	2025	4	2025-04-01	2025-04-30	2025	2	f	\N	\N	2025-11-04 03:22:52.07227+00
4	3	2023	12	2023-12-01	2023-12-31	2023	4	f	\N	\N	2025-11-04 03:22:52.297+00
5	3	2024	12	2024-12-01	2024-12-31	2024	4	f	\N	\N	2025-11-04 03:22:53.005174+00
6	3	2025	4	2025-04-01	2025-04-30	2025	2	f	\N	\N	2025-11-04 03:22:53.351095+00
7	4	2023	12	2023-12-01	2023-12-31	2023	4	f	\N	\N	2025-11-04 03:22:53.725543+00
8	4	2024	12	2024-12-01	2024-12-31	2024	4	f	\N	\N	2025-11-04 03:22:54.472107+00
9	4	2025	4	2025-04-01	2025-04-30	2025	2	f	\N	\N	2025-11-04 03:22:55.259866+00
10	5	2023	12	2023-12-01	2023-12-31	2023	4	f	\N	\N	2025-11-04 03:22:55.567455+00
11	5	2024	12	2024-12-01	2024-12-31	2024	4	f	\N	\N	2025-11-04 03:22:56.357427+00
12	5	2025	4	2025-04-01	2025-04-30	2025	2	f	\N	\N	2025-11-04 03:22:57.130639+00
\.


--
-- Data for Name: income_statement_data; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.income_statement_data (id, property_id, period_id, upload_id, account_id, account_code, account_name, period_amount, ytd_amount, period_percentage, ytd_percentage, is_income, is_calculated, parent_account_code, extraction_confidence, needs_review, reviewed, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.properties (id, property_code, property_name, property_type, address, city, state, zip_code, country, total_area_sqft, acquisition_date, ownership_structure, status, notes, created_at, updated_at, created_by) FROM stdin;
1	TEST001	Test Property	multifamily	123 Test St	Test City	TS	12345	USA	\N	\N	\N	active	\N	2025-11-04 02:31:20.654241+00	\N	1
2	ESP001	Esplanade Shopping Center	retail	1234 Main Street	Phoenix	AZ	85001	USA	125000.50	2020-01-15	LLC	active	Premium shopping center in Phoenix metro area	2025-11-04 03:12:43.586502+00	\N	\N
3	HMND001	Hammond Aire Shopping Center	retail	5678 Commerce Drive	Hammond	IN	46320	USA	98500.00	2019-06-01	Partnership	active	Regional shopping center in Hammond, Indiana	2025-11-04 03:12:43.586502+00	\N	\N
4	TCSH001	Town Center Shopping	retail	9012 Center Boulevard	Town Center	FL	33411	USA	110250.00	2021-03-20	LLC	active	Mixed-use retail center in South Florida	2025-11-04 03:12:43.586502+00	\N	\N
5	WEND001	Wendover Commons	retail	3456 Wendover Avenue	Greensboro	NC	27407	USA	87600.00	2018-11-10	LLC	active	Community shopping center in Greensboro, NC	2025-11-04 03:12:43.586502+00	\N	\N
\.


--
-- Data for Name: rent_roll_data; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.rent_roll_data (id, property_id, period_id, upload_id, unit_number, tenant_name, tenant_code, lease_type, lease_start_date, lease_end_date, lease_term_months, remaining_lease_years, unit_area_sqft, monthly_rent, monthly_rent_per_sqft, annual_rent, annual_rent_per_sqft, gross_rent, security_deposit, loc_amount, annual_cam_reimbursement, annual_tax_reimbursement, annual_insurance_reimbursement, occupancy_status, lease_status, extraction_confidence, needs_review, reviewed, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.users (id, email, username, hashed_password, is_active, is_superuser, created_at, updated_at) FROM stdin;
1	system@reims.local	system	not_used	t	t	2025-11-03 23:06:21.107128+00	\N
\.


--
-- Data for Name: validation_results; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.validation_results (id, upload_id, rule_id, passed, expected_value, actual_value, difference, difference_percentage, error_message, severity, created_at) FROM stdin;
\.


--
-- Data for Name: validation_rules; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.validation_rules (id, rule_name, rule_description, document_type, rule_type, rule_formula, error_message, severity, is_active, created_at) FROM stdin;
\.


--
-- Name: audit_trail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.audit_trail_id_seq', 1, false);


--
-- Name: balance_sheet_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.balance_sheet_data_id_seq', 1, false);


--
-- Name: cash_flow_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.cash_flow_data_id_seq', 1, false);


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.chart_of_accounts_id_seq', 1, false);


--
-- Name: document_uploads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.document_uploads_id_seq', 28, true);


--
-- Name: extraction_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.extraction_logs_id_seq', 1, false);


--
-- Name: extraction_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.extraction_templates_id_seq', 1, false);


--
-- Name: financial_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.financial_metrics_id_seq', 1, false);


--
-- Name: financial_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.financial_periods_id_seq', 12, true);


--
-- Name: income_statement_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.income_statement_data_id_seq', 1, false);


--
-- Name: properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.properties_id_seq', 5, true);


--
-- Name: rent_roll_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.rent_roll_data_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: validation_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.validation_results_id_seq', 1, false);


--
-- Name: validation_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.validation_rules_id_seq', 1, false);


--
-- Name: audit_trail audit_trail_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_pkey PRIMARY KEY (id);


--
-- Name: balance_sheet_data balance_sheet_data_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_pkey PRIMARY KEY (id);


--
-- Name: cash_flow_data cash_flow_data_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_pkey PRIMARY KEY (id);


--
-- Name: chart_of_accounts chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);


--
-- Name: document_uploads document_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT document_uploads_pkey PRIMARY KEY (id);


--
-- Name: extraction_logs extraction_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.extraction_logs
    ADD CONSTRAINT extraction_logs_pkey PRIMARY KEY (id);


--
-- Name: extraction_templates extraction_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.extraction_templates
    ADD CONSTRAINT extraction_templates_pkey PRIMARY KEY (id);


--
-- Name: extraction_templates extraction_templates_template_name_key; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.extraction_templates
    ADD CONSTRAINT extraction_templates_template_name_key UNIQUE (template_name);


--
-- Name: financial_metrics financial_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT financial_metrics_pkey PRIMARY KEY (id);


--
-- Name: financial_periods financial_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT financial_periods_pkey PRIMARY KEY (id);


--
-- Name: income_statement_data income_statement_data_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: rent_roll_data rent_roll_data_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT rent_roll_data_pkey PRIMARY KEY (id);


--
-- Name: balance_sheet_data uq_bs_property_period_account; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT uq_bs_property_period_account UNIQUE (property_id, period_id, account_code);


--
-- Name: cash_flow_data uq_cf_property_period_account; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT uq_cf_property_period_account UNIQUE (property_id, period_id, account_code);


--
-- Name: income_statement_data uq_is_property_period_account; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT uq_is_property_period_account UNIQUE (property_id, period_id, account_code);


--
-- Name: financial_metrics uq_metrics_property_period; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT uq_metrics_property_period UNIQUE (property_id, period_id);


--
-- Name: financial_periods uq_property_period; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT uq_property_period UNIQUE (property_id, period_year, period_month);


--
-- Name: document_uploads uq_property_period_doctype_version; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT uq_property_period_doctype_version UNIQUE (property_id, period_id, document_type, version);


--
-- Name: rent_roll_data uq_rr_property_period_unit; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT uq_rr_property_period_unit UNIQUE (property_id, period_id, unit_number);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: validation_results validation_results_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_results
    ADD CONSTRAINT validation_results_pkey PRIMARY KEY (id);


--
-- Name: validation_rules validation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_rules
    ADD CONSTRAINT validation_rules_pkey PRIMARY KEY (id);


--
-- Name: validation_rules validation_rules_rule_name_key; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_rules
    ADD CONSTRAINT validation_rules_rule_name_key UNIQUE (rule_name);


--
-- Name: ix_audit_trail_changed_at; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_audit_trail_changed_at ON public.audit_trail USING btree (changed_at);


--
-- Name: ix_audit_trail_changed_by; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_audit_trail_changed_by ON public.audit_trail USING btree (changed_by);


--
-- Name: ix_audit_trail_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_audit_trail_id ON public.audit_trail USING btree (id);


--
-- Name: ix_audit_trail_record_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_audit_trail_record_id ON public.audit_trail USING btree (record_id);


--
-- Name: ix_audit_trail_table_name; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_audit_trail_table_name ON public.audit_trail USING btree (table_name);


--
-- Name: ix_balance_sheet_data_account_code; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_balance_sheet_data_account_code ON public.balance_sheet_data USING btree (account_code);


--
-- Name: ix_balance_sheet_data_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_balance_sheet_data_id ON public.balance_sheet_data USING btree (id);


--
-- Name: ix_balance_sheet_data_needs_review; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_balance_sheet_data_needs_review ON public.balance_sheet_data USING btree (needs_review);


--
-- Name: ix_balance_sheet_data_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_balance_sheet_data_period_id ON public.balance_sheet_data USING btree (period_id);


--
-- Name: ix_balance_sheet_data_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_balance_sheet_data_property_id ON public.balance_sheet_data USING btree (property_id);


--
-- Name: ix_cash_flow_data_cash_flow_category; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_cash_flow_data_cash_flow_category ON public.cash_flow_data USING btree (cash_flow_category);


--
-- Name: ix_cash_flow_data_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_cash_flow_data_id ON public.cash_flow_data USING btree (id);


--
-- Name: ix_cash_flow_data_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_cash_flow_data_period_id ON public.cash_flow_data USING btree (period_id);


--
-- Name: ix_cash_flow_data_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_cash_flow_data_property_id ON public.cash_flow_data USING btree (property_id);


--
-- Name: ix_chart_of_accounts_account_code; Type: INDEX; Schema: public; Owner: reims
--

CREATE UNIQUE INDEX ix_chart_of_accounts_account_code ON public.chart_of_accounts USING btree (account_code);


--
-- Name: ix_chart_of_accounts_account_type; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_chart_of_accounts_account_type ON public.chart_of_accounts USING btree (account_type);


--
-- Name: ix_chart_of_accounts_category; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_chart_of_accounts_category ON public.chart_of_accounts USING btree (category);


--
-- Name: ix_chart_of_accounts_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_chart_of_accounts_id ON public.chart_of_accounts USING btree (id);


--
-- Name: ix_document_uploads_document_type; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_document_uploads_document_type ON public.document_uploads USING btree (document_type);


--
-- Name: ix_document_uploads_extraction_status; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_document_uploads_extraction_status ON public.document_uploads USING btree (extraction_status);


--
-- Name: ix_document_uploads_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_document_uploads_id ON public.document_uploads USING btree (id);


--
-- Name: ix_document_uploads_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_document_uploads_period_id ON public.document_uploads USING btree (period_id);


--
-- Name: ix_document_uploads_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_document_uploads_property_id ON public.document_uploads USING btree (property_id);


--
-- Name: ix_extraction_logs_file_hash; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_extraction_logs_file_hash ON public.extraction_logs USING btree (file_hash);


--
-- Name: ix_extraction_logs_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_extraction_logs_id ON public.extraction_logs USING btree (id);


--
-- Name: ix_extraction_templates_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_extraction_templates_id ON public.extraction_templates USING btree (id);


--
-- Name: ix_financial_metrics_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_metrics_id ON public.financial_metrics USING btree (id);


--
-- Name: ix_financial_metrics_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_metrics_period_id ON public.financial_metrics USING btree (period_id);


--
-- Name: ix_financial_metrics_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_metrics_property_id ON public.financial_metrics USING btree (property_id);


--
-- Name: ix_financial_periods_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_periods_id ON public.financial_periods USING btree (id);


--
-- Name: ix_financial_periods_period_year; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_periods_period_year ON public.financial_periods USING btree (period_year);


--
-- Name: ix_financial_periods_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_periods_property_id ON public.financial_periods USING btree (property_id);


--
-- Name: ix_income_statement_data_account_code; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_income_statement_data_account_code ON public.income_statement_data USING btree (account_code);


--
-- Name: ix_income_statement_data_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_income_statement_data_id ON public.income_statement_data USING btree (id);


--
-- Name: ix_income_statement_data_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_income_statement_data_period_id ON public.income_statement_data USING btree (period_id);


--
-- Name: ix_income_statement_data_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_income_statement_data_property_id ON public.income_statement_data USING btree (property_id);


--
-- Name: ix_properties_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_properties_id ON public.properties USING btree (id);


--
-- Name: ix_properties_property_code; Type: INDEX; Schema: public; Owner: reims
--

CREATE UNIQUE INDEX ix_properties_property_code ON public.properties USING btree (property_code);


--
-- Name: ix_properties_status; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_properties_status ON public.properties USING btree (status);


--
-- Name: ix_rent_roll_data_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_id ON public.rent_roll_data USING btree (id);


--
-- Name: ix_rent_roll_data_lease_end_date; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_lease_end_date ON public.rent_roll_data USING btree (lease_end_date);


--
-- Name: ix_rent_roll_data_occupancy_status; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_occupancy_status ON public.rent_roll_data USING btree (occupancy_status);


--
-- Name: ix_rent_roll_data_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_period_id ON public.rent_roll_data USING btree (period_id);


--
-- Name: ix_rent_roll_data_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_property_id ON public.rent_roll_data USING btree (property_id);


--
-- Name: ix_rent_roll_data_tenant_name; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_tenant_name ON public.rent_roll_data USING btree (tenant_name);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: reims
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: reims
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_validation_results_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_validation_results_id ON public.validation_results USING btree (id);


--
-- Name: ix_validation_results_passed; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_validation_results_passed ON public.validation_results USING btree (passed);


--
-- Name: ix_validation_results_upload_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_validation_results_upload_id ON public.validation_results USING btree (upload_id);


--
-- Name: ix_validation_rules_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_validation_rules_id ON public.validation_rules USING btree (id);


--
-- Name: audit_trail audit_trail_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- Name: balance_sheet_data balance_sheet_data_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: balance_sheet_data balance_sheet_data_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: balance_sheet_data balance_sheet_data_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: balance_sheet_data balance_sheet_data_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: balance_sheet_data balance_sheet_data_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.document_uploads(id) ON DELETE SET NULL;


--
-- Name: cash_flow_data cash_flow_data_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: cash_flow_data cash_flow_data_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: cash_flow_data cash_flow_data_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: cash_flow_data cash_flow_data_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: cash_flow_data cash_flow_data_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.document_uploads(id) ON DELETE SET NULL;


--
-- Name: document_uploads document_uploads_extraction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT document_uploads_extraction_id_fkey FOREIGN KEY (extraction_id) REFERENCES public.extraction_logs(id);


--
-- Name: document_uploads document_uploads_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT document_uploads_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: document_uploads document_uploads_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT document_uploads_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: document_uploads document_uploads_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT document_uploads_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: financial_metrics financial_metrics_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT financial_metrics_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: financial_metrics financial_metrics_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT financial_metrics_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: financial_periods financial_periods_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT financial_periods_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id);


--
-- Name: financial_periods financial_periods_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT financial_periods_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: income_statement_data income_statement_data_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: income_statement_data income_statement_data_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: income_statement_data income_statement_data_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: income_statement_data income_statement_data_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: income_statement_data income_statement_data_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.document_uploads(id) ON DELETE SET NULL;


--
-- Name: properties properties_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: rent_roll_data rent_roll_data_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT rent_roll_data_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: rent_roll_data rent_roll_data_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT rent_roll_data_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: rent_roll_data rent_roll_data_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT rent_roll_data_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: rent_roll_data rent_roll_data_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT rent_roll_data_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.document_uploads(id) ON DELETE SET NULL;


--
-- Name: validation_results validation_results_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_results
    ADD CONSTRAINT validation_results_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.validation_rules(id);


--
-- Name: validation_results validation_results_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_results
    ADD CONSTRAINT validation_results_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.document_uploads(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict vxVE1mlGVbPtfqdzGN9jKQPFB2FskKJTVnyYyf3sGR6BnYwBhoClK7vDdWDqwlV

