--
-- PostgreSQL database dump
--

\restrict hfcBwGPF36M2jOwZPcOcJYZAuOWjab5cCVJ3wkuUCUrroJgRPXLBPxpPtrXDCbl

-- Dumped from database version 17.6 (Debian 17.6-2.pgdg13+1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-2.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_trail; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.audit_trail (
    id integer NOT NULL,
    table_name character varying(100) NOT NULL,
    record_id integer NOT NULL,
    action character varying(50) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_fields text[],
    changed_by integer,
    changed_at timestamp with time zone DEFAULT now(),
    reason text,
    ip_address inet
);


ALTER TABLE public.audit_trail OWNER TO reims;

--
-- Name: audit_trail_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.audit_trail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_trail_id_seq OWNER TO reims;

--
-- Name: audit_trail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.audit_trail_id_seq OWNED BY public.audit_trail.id;


--
-- Name: balance_sheet_data; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.balance_sheet_data (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    upload_id integer,
    account_id integer,
    account_code character varying(50) NOT NULL,
    account_name character varying(255) NOT NULL,
    amount numeric(15,2) NOT NULL,
    is_debit boolean,
    is_calculated boolean,
    parent_account_code character varying(50),
    extraction_confidence numeric(5,2),
    needs_review boolean,
    reviewed boolean,
    reviewed_by integer,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.balance_sheet_data OWNER TO reims;

--
-- Name: balance_sheet_data_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.balance_sheet_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.balance_sheet_data_id_seq OWNER TO reims;

--
-- Name: balance_sheet_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.balance_sheet_data_id_seq OWNED BY public.balance_sheet_data.id;


--
-- Name: cash_flow_data; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.cash_flow_data (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    upload_id integer,
    account_id integer,
    account_code character varying(50) NOT NULL,
    account_name character varying(255) NOT NULL,
    period_amount numeric(15,2) NOT NULL,
    ytd_amount numeric(15,2),
    period_percentage numeric(5,2),
    ytd_percentage numeric(5,2),
    cash_flow_category character varying(50),
    is_inflow boolean,
    is_calculated boolean,
    parent_account_code character varying(50),
    extraction_confidence numeric(5,2),
    needs_review boolean,
    reviewed boolean,
    reviewed_by integer,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.cash_flow_data OWNER TO reims;

--
-- Name: cash_flow_data_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.cash_flow_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cash_flow_data_id_seq OWNER TO reims;

--
-- Name: cash_flow_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.cash_flow_data_id_seq OWNED BY public.cash_flow_data.id;


--
-- Name: chart_of_accounts; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.chart_of_accounts (
    id integer NOT NULL,
    account_code character varying(50) NOT NULL,
    account_name character varying(255) NOT NULL,
    account_type character varying(50) NOT NULL,
    category character varying(100),
    subcategory character varying(100),
    parent_account_code character varying(50),
    document_types text[],
    is_calculated boolean,
    calculation_formula text,
    display_order integer,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.chart_of_accounts OWNER TO reims;

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.chart_of_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chart_of_accounts_id_seq OWNER TO reims;

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.chart_of_accounts_id_seq OWNED BY public.chart_of_accounts.id;


--
-- Name: document_uploads; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.document_uploads (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    document_type character varying(50) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(500),
    file_hash character varying(64),
    file_size_bytes bigint,
    upload_date timestamp with time zone DEFAULT now(),
    uploaded_by integer,
    extraction_status character varying(50),
    extraction_started_at timestamp with time zone,
    extraction_completed_at timestamp with time zone,
    extraction_id integer,
    version integer,
    is_active boolean,
    notes text
);


ALTER TABLE public.document_uploads OWNER TO reims;

--
-- Name: document_uploads_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.document_uploads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.document_uploads_id_seq OWNER TO reims;

--
-- Name: document_uploads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.document_uploads_id_seq OWNED BY public.document_uploads.id;


--
-- Name: extraction_logs; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.extraction_logs (
    id integer NOT NULL,
    filename character varying NOT NULL,
    file_size integer,
    file_hash character varying,
    document_type character varying,
    total_pages integer,
    strategy_used character varying,
    engines_used json,
    primary_engine character varying,
    confidence_score double precision,
    quality_level character varying,
    passed_checks integer,
    total_checks integer,
    processing_time_seconds double precision,
    extraction_timestamp timestamp with time zone DEFAULT now(),
    validation_issues json,
    validation_warnings json,
    recommendations json,
    extracted_text text,
    text_preview character varying(500),
    total_words integer,
    total_chars integer,
    tables_found integer,
    images_found integer,
    needs_review boolean,
    reviewed boolean,
    reviewed_by character varying,
    reviewed_at timestamp with time zone,
    review_notes text,
    custom_metadata json,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.extraction_logs OWNER TO reims;

--
-- Name: extraction_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.extraction_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.extraction_logs_id_seq OWNER TO reims;

--
-- Name: extraction_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.extraction_logs_id_seq OWNED BY public.extraction_logs.id;


--
-- Name: extraction_templates; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.extraction_templates (
    id integer NOT NULL,
    template_name character varying(100) NOT NULL,
    document_type character varying(50) NOT NULL,
    template_structure jsonb,
    keywords text[],
    extraction_rules jsonb,
    is_default boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.extraction_templates OWNER TO reims;

--
-- Name: extraction_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.extraction_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.extraction_templates_id_seq OWNER TO reims;

--
-- Name: extraction_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.extraction_templates_id_seq OWNED BY public.extraction_templates.id;


--
-- Name: financial_metrics; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.financial_metrics (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    total_assets numeric(15,2),
    total_liabilities numeric(15,2),
    total_equity numeric(15,2),
    current_ratio numeric(10,4),
    debt_to_equity_ratio numeric(10,4),
    total_revenue numeric(15,2),
    total_expenses numeric(15,2),
    net_operating_income numeric(15,2),
    net_income numeric(15,2),
    operating_margin numeric(10,4),
    profit_margin numeric(10,4),
    operating_cash_flow numeric(15,2),
    investing_cash_flow numeric(15,2),
    financing_cash_flow numeric(15,2),
    net_cash_flow numeric(15,2),
    beginning_cash_balance numeric(15,2),
    ending_cash_balance numeric(15,2),
    total_units integer,
    occupied_units integer,
    vacant_units integer,
    occupancy_rate numeric(5,2),
    total_leasable_sqft numeric(12,2),
    occupied_sqft numeric(12,2),
    total_monthly_rent numeric(12,2),
    total_annual_rent numeric(12,2),
    avg_rent_per_sqft numeric(10,4),
    noi_per_sqft numeric(10,4),
    revenue_per_sqft numeric(10,4),
    expense_ratio numeric(5,2),
    calculated_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.financial_metrics OWNER TO reims;

--
-- Name: financial_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.financial_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.financial_metrics_id_seq OWNER TO reims;

--
-- Name: financial_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.financial_metrics_id_seq OWNED BY public.financial_metrics.id;


--
-- Name: financial_periods; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.financial_periods (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_year integer NOT NULL,
    period_month integer NOT NULL,
    period_start_date date NOT NULL,
    period_end_date date NOT NULL,
    fiscal_year integer,
    fiscal_quarter integer,
    is_closed boolean,
    closed_date timestamp with time zone,
    closed_by integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.financial_periods OWNER TO reims;

--
-- Name: financial_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.financial_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.financial_periods_id_seq OWNER TO reims;

--
-- Name: financial_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.financial_periods_id_seq OWNED BY public.financial_periods.id;


--
-- Name: income_statement_data; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.income_statement_data (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    upload_id integer,
    account_id integer,
    account_code character varying(50) NOT NULL,
    account_name character varying(255) NOT NULL,
    period_amount numeric(15,2) NOT NULL,
    ytd_amount numeric(15,2),
    period_percentage numeric(5,2),
    ytd_percentage numeric(5,2),
    is_income boolean,
    is_calculated boolean,
    parent_account_code character varying(50),
    extraction_confidence numeric(5,2),
    needs_review boolean,
    reviewed boolean,
    reviewed_by integer,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.income_statement_data OWNER TO reims;

--
-- Name: income_statement_data_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.income_statement_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.income_statement_data_id_seq OWNER TO reims;

--
-- Name: income_statement_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.income_statement_data_id_seq OWNED BY public.income_statement_data.id;


--
-- Name: properties; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.properties (
    id integer NOT NULL,
    property_code character varying(50) NOT NULL,
    property_name character varying(255) NOT NULL,
    property_type character varying(50),
    address text,
    city character varying(100),
    state character varying(50),
    zip_code character varying(20),
    country character varying(50),
    total_area_sqft numeric(12,2),
    acquisition_date date,
    ownership_structure character varying(100),
    status character varying(50),
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by integer
);


ALTER TABLE public.properties OWNER TO reims;

--
-- Name: properties_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.properties_id_seq OWNER TO reims;

--
-- Name: properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.properties_id_seq OWNED BY public.properties.id;


--
-- Name: rent_roll_data; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.rent_roll_data (
    id integer NOT NULL,
    property_id integer NOT NULL,
    period_id integer NOT NULL,
    upload_id integer,
    unit_number character varying(50) NOT NULL,
    tenant_name character varying(255) NOT NULL,
    tenant_code character varying(50),
    lease_type character varying(50),
    lease_start_date date,
    lease_end_date date,
    lease_term_months integer,
    remaining_lease_years numeric(5,2),
    unit_area_sqft numeric(10,2),
    monthly_rent numeric(12,2),
    monthly_rent_per_sqft numeric(10,4),
    annual_rent numeric(12,2),
    annual_rent_per_sqft numeric(10,4),
    gross_rent numeric(12,2),
    security_deposit numeric(12,2),
    loc_amount numeric(12,2),
    annual_cam_reimbursement numeric(12,2),
    annual_tax_reimbursement numeric(12,2),
    annual_insurance_reimbursement numeric(12,2),
    occupancy_status character varying(50),
    lease_status character varying(50),
    extraction_confidence numeric(5,2),
    needs_review boolean,
    reviewed boolean,
    reviewed_by integer,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.rent_roll_data OWNER TO reims;

--
-- Name: rent_roll_data_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.rent_roll_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rent_roll_data_id_seq OWNER TO reims;

--
-- Name: rent_roll_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.rent_roll_data_id_seq OWNED BY public.rent_roll_data.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying NOT NULL,
    username character varying NOT NULL,
    hashed_password character varying NOT NULL,
    is_active boolean,
    is_superuser boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO reims;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO reims;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: v_extraction_quality_dashboard; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_extraction_quality_dashboard AS
 SELECT p.property_code,
    p.property_name,
    fp.period_year,
    fp.period_month,
    du.document_type,
    du.file_name,
    du.extraction_status,
    el.confidence_score,
    el.quality_level,
    el.passed_checks,
    el.total_checks,
    el.needs_review,
    du.upload_date,
    du.extraction_completed_at,
    EXTRACT(epoch FROM (du.extraction_completed_at - du.extraction_started_at)) AS processing_seconds
   FROM (((public.document_uploads du
     JOIN public.properties p ON ((du.property_id = p.id)))
     JOIN public.financial_periods fp ON ((du.period_id = fp.id)))
     LEFT JOIN public.extraction_logs el ON ((du.extraction_id = el.id)))
  WHERE (du.is_active = true)
  ORDER BY du.upload_date DESC;


ALTER VIEW public.v_extraction_quality_dashboard OWNER TO reims;

--
-- Name: v_monthly_comparison; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_monthly_comparison AS
 SELECT p.property_code,
    p.property_name,
    isd.account_code,
    isd.account_name,
    fp.period_year,
    fp.period_month,
    isd.period_amount AS current_month,
    lag(isd.period_amount) OVER (PARTITION BY isd.property_id, isd.account_code ORDER BY fp.period_year, fp.period_month) AS previous_month,
    (isd.period_amount - lag(isd.period_amount) OVER (PARTITION BY isd.property_id, isd.account_code ORDER BY fp.period_year, fp.period_month)) AS month_variance,
    round((((isd.period_amount - lag(isd.period_amount) OVER (PARTITION BY isd.property_id, isd.account_code ORDER BY fp.period_year, fp.period_month)) / NULLIF(lag(isd.period_amount) OVER (PARTITION BY isd.property_id, isd.account_code ORDER BY fp.period_year, fp.period_month), (0)::numeric)) * (100)::numeric), 2) AS variance_percentage,
    isd.ytd_amount,
    isd.is_income
   FROM ((public.income_statement_data isd
     JOIN public.financial_periods fp ON ((isd.period_id = fp.id)))
     JOIN public.properties p ON ((isd.property_id = p.id)))
  WHERE ((p.status)::text = 'active'::text)
  ORDER BY p.property_code, fp.period_year DESC, fp.period_month DESC, isd.account_code;


ALTER VIEW public.v_monthly_comparison OWNER TO reims;

--
-- Name: v_multi_property_comparison; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_multi_property_comparison AS
 SELECT fp.period_year,
    fp.period_month,
    p.property_code,
    p.property_name,
    p.property_type,
    p.total_area_sqft,
    fm.total_revenue,
    fm.net_operating_income,
    fm.net_income,
    fm.occupancy_rate,
    fm.noi_per_sqft,
    fm.revenue_per_sqft,
    fm.expense_ratio,
    fm.operating_margin,
    rank() OVER (PARTITION BY fp.period_year, fp.period_month ORDER BY fm.net_operating_income DESC) AS noi_rank,
    rank() OVER (PARTITION BY fp.period_year, fp.period_month ORDER BY fm.occupancy_rate DESC) AS occupancy_rank
   FROM ((public.properties p
     JOIN public.financial_periods fp ON ((p.id = fp.property_id)))
     LEFT JOIN public.financial_metrics fm ON ((fp.id = fm.period_id)))
  WHERE ((p.status)::text = 'active'::text)
  ORDER BY fp.period_year DESC, fp.period_month DESC, fm.net_operating_income DESC;


ALTER VIEW public.v_multi_property_comparison OWNER TO reims;

--
-- Name: v_property_financial_summary; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_property_financial_summary AS
 SELECT p.property_code,
    p.property_name,
    p.property_type,
    p.city,
    p.state,
    fp.period_year,
    fp.period_month,
    fp.period_start_date,
    fp.period_end_date,
    fm.total_assets,
    fm.total_liabilities,
    fm.total_equity,
    fm.current_ratio,
    fm.debt_to_equity_ratio,
    fm.total_revenue,
    fm.total_expenses,
    fm.net_operating_income,
    fm.net_income,
    fm.operating_margin,
    fm.profit_margin,
    fm.operating_cash_flow,
    fm.investing_cash_flow,
    fm.financing_cash_flow,
    fm.net_cash_flow,
    fm.ending_cash_balance,
    fm.total_units,
    fm.occupied_units,
    fm.vacant_units,
    fm.occupancy_rate,
    fm.total_annual_rent,
    fm.avg_rent_per_sqft,
    fm.noi_per_sqft,
    fm.revenue_per_sqft,
    fm.expense_ratio,
    fm.calculated_at
   FROM ((public.properties p
     JOIN public.financial_periods fp ON ((p.id = fp.property_id)))
     LEFT JOIN public.financial_metrics fm ON ((fp.id = fm.period_id)))
  WHERE ((p.status)::text = 'active'::text)
  ORDER BY p.property_code, fp.period_year DESC, fp.period_month DESC;


ALTER VIEW public.v_property_financial_summary OWNER TO reims;

--
-- Name: validation_results; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.validation_results (
    id integer NOT NULL,
    upload_id integer NOT NULL,
    rule_id integer NOT NULL,
    passed boolean NOT NULL,
    expected_value numeric(15,2),
    actual_value numeric(15,2),
    difference numeric(15,2),
    difference_percentage numeric(10,4),
    error_message text,
    severity character varying(20),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.validation_results OWNER TO reims;

--
-- Name: validation_rules; Type: TABLE; Schema: public; Owner: reims
--

CREATE TABLE public.validation_rules (
    id integer NOT NULL,
    rule_name character varying(100) NOT NULL,
    rule_description text,
    document_type character varying(50) NOT NULL,
    rule_type character varying(50) NOT NULL,
    rule_formula text,
    error_message text,
    severity character varying(20),
    is_active boolean,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.validation_rules OWNER TO reims;

--
-- Name: v_validation_issues; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_validation_issues AS
 SELECT p.property_code,
    p.property_name,
    fp.period_year,
    fp.period_month,
    du.document_type,
    vr.rule_name,
    vr.rule_description,
    vres.passed,
    vres.expected_value,
    vres.actual_value,
    vres.difference,
    vres.difference_percentage,
    vres.error_message,
    vres.severity,
    vres.created_at
   FROM ((((public.validation_results vres
     JOIN public.validation_rules vr ON ((vres.rule_id = vr.id)))
     JOIN public.document_uploads du ON ((vres.upload_id = du.id)))
     JOIN public.properties p ON ((du.property_id = p.id)))
     JOIN public.financial_periods fp ON ((du.period_id = fp.id)))
  WHERE ((vres.passed = false) AND (vr.is_active = true))
  ORDER BY vres.severity DESC, vres.created_at DESC;


ALTER VIEW public.v_validation_issues OWNER TO reims;

--
-- Name: v_ytd_rollup; Type: VIEW; Schema: public; Owner: reims
--

CREATE VIEW public.v_ytd_rollup AS
 SELECT p.property_code,
    p.property_name,
    fp.fiscal_year,
    sum(fm.total_revenue) AS ytd_revenue,
    sum(fm.total_expenses) AS ytd_expenses,
    sum(fm.net_operating_income) AS ytd_noi,
    sum(fm.net_income) AS ytd_net_income,
    avg(fm.occupancy_rate) AS avg_occupancy_rate,
    max(fm.ending_cash_balance) AS latest_cash_balance,
    count(DISTINCT fp.id) AS periods_reported
   FROM ((public.properties p
     JOIN public.financial_periods fp ON ((p.id = fp.property_id)))
     LEFT JOIN public.financial_metrics fm ON ((fp.id = fm.period_id)))
  WHERE ((p.status)::text = 'active'::text)
  GROUP BY p.property_code, p.property_name, fp.fiscal_year
  ORDER BY p.property_code, fp.fiscal_year DESC;


ALTER VIEW public.v_ytd_rollup OWNER TO reims;

--
-- Name: validation_results_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.validation_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.validation_results_id_seq OWNER TO reims;

--
-- Name: validation_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.validation_results_id_seq OWNED BY public.validation_results.id;


--
-- Name: validation_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: reims
--

CREATE SEQUENCE public.validation_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.validation_rules_id_seq OWNER TO reims;

--
-- Name: validation_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: reims
--

ALTER SEQUENCE public.validation_rules_id_seq OWNED BY public.validation_rules.id;


--
-- Name: audit_trail id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.audit_trail ALTER COLUMN id SET DEFAULT nextval('public.audit_trail_id_seq'::regclass);


--
-- Name: balance_sheet_data id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data ALTER COLUMN id SET DEFAULT nextval('public.balance_sheet_data_id_seq'::regclass);


--
-- Name: cash_flow_data id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data ALTER COLUMN id SET DEFAULT nextval('public.cash_flow_data_id_seq'::regclass);


--
-- Name: chart_of_accounts id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.chart_of_accounts ALTER COLUMN id SET DEFAULT nextval('public.chart_of_accounts_id_seq'::regclass);


--
-- Name: document_uploads id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads ALTER COLUMN id SET DEFAULT nextval('public.document_uploads_id_seq'::regclass);


--
-- Name: extraction_logs id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.extraction_logs ALTER COLUMN id SET DEFAULT nextval('public.extraction_logs_id_seq'::regclass);


--
-- Name: extraction_templates id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.extraction_templates ALTER COLUMN id SET DEFAULT nextval('public.extraction_templates_id_seq'::regclass);


--
-- Name: financial_metrics id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_metrics ALTER COLUMN id SET DEFAULT nextval('public.financial_metrics_id_seq'::regclass);


--
-- Name: financial_periods id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_periods ALTER COLUMN id SET DEFAULT nextval('public.financial_periods_id_seq'::regclass);


--
-- Name: income_statement_data id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data ALTER COLUMN id SET DEFAULT nextval('public.income_statement_data_id_seq'::regclass);


--
-- Name: properties id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.properties ALTER COLUMN id SET DEFAULT nextval('public.properties_id_seq'::regclass);


--
-- Name: rent_roll_data id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data ALTER COLUMN id SET DEFAULT nextval('public.rent_roll_data_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: validation_results id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_results ALTER COLUMN id SET DEFAULT nextval('public.validation_results_id_seq'::regclass);


--
-- Name: validation_rules id; Type: DEFAULT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_rules ALTER COLUMN id SET DEFAULT nextval('public.validation_rules_id_seq'::regclass);


--
-- Data for Name: audit_trail; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.audit_trail (id, table_name, record_id, action, old_values, new_values, changed_fields, changed_by, changed_at, reason, ip_address) FROM stdin;
\.


--
-- Data for Name: balance_sheet_data; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.balance_sheet_data (id, property_id, period_id, upload_id, account_id, account_code, account_name, amount, is_debit, is_calculated, parent_account_code, extraction_confidence, needs_review, reviewed, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
36	3	4	8	19	1091-0000	Accum. Depr.-Other Imp.	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:36.649349+00	\N
37	3	4	8	43	2132-0000	A/P 5Rivers CRE, LLC	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:36.649349+00	\N
38	3	4	8	44	2197-0000	Loans Payable 5Rivers	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:36.649349+00	\N
39	2	2	4	6	0305-0000	A/R Tenants	5.00	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:50:36.63878+00	\N
40	2	2	4	19	1091-0000	Accum. Depr.-Other Imp.	5.00	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:50:36.63878+00	\N
41	2	2	4	35	1952-0000	Accum. Amort - TI/LC	2016.00	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:50:36.63878+00	\N
42	2	2	4	43	2132-0000	A/P 5Rivers CRE, LLC	5.00	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:50:36.63878+00	\N
43	2	2	4	44	2197-0000	Loans Payable 5Rivers	5.00	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:50:36.63878+00	\N
44	3	5	11	6	0305-0000	A/R Tenants	5.00	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:50:38.33983+00	\N
45	3	5	11	19	1091-0000	Accum. Depr.-Other Imp.	5.00	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:50:38.33983+00	\N
46	3	5	11	35	1952-0000	Accum. Amort - TI/LC	2016.00	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:50:38.33983+00	\N
47	3	5	11	43	2132-0000	A/P 5Rivers CRE, LLC	5.00	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:50:38.33983+00	\N
48	3	5	11	44	2197-0000	Loans Payable 5Rivers	5.00	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:50:38.33983+00	\N
49	2	1	1	19	1091-0000	Accum. Depr.-Other Imp.	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:39.77183+00	\N
50	2	1	1	43	2132-0000	A/P 5Rivers CRE, LLC	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:39.77183+00	\N
51	2	1	1	44	2197-0000	Loans Payable 5Rivers	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:39.77183+00	\N
52	4	7	13	19	1091-0000	Accum. Depr.-Other Imp.	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:40.62692+00	\N
53	4	7	13	43	2132-0000	A/P 5Rivers CRE, LLC	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:40.62692+00	\N
54	4	8	16	19	1091-0000	Accum. Depr.-Other Imp.	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:41.298832+00	\N
55	4	8	16	43	2132-0000	A/P 5Rivers CRE, LLC	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:41.298832+00	\N
56	4	8	16	44	2197-0000	Loans Payable 5Rivers	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:41.298832+00	\N
57	5	10	20	19	1091-0000	Accum. Depr.-Other Imp.	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:42.466097+00	\N
58	5	10	20	43	2132-0000	A/P 5Rivers CRE, LLC	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:42.466097+00	\N
59	5	10	20	44	2197-0000	Loans Payable 5Rivers	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:42.466097+00	\N
60	5	11	23	19	1091-0000	Accum. Depr.-Other Imp.	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:44.829412+00	\N
61	5	11	23	43	2132-0000	A/P 5Rivers CRE, LLC	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:44.829412+00	\N
62	5	11	23	44	2197-0000	Loans Payable 5Rivers	5.00	\N	f	\N	92.00	f	f	\N	\N	\N	2025-11-04 03:50:44.829412+00	\N
\.


--
-- Data for Name: cash_flow_data; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.cash_flow_data (id, property_id, period_id, upload_id, account_id, account_code, account_name, period_amount, ytd_amount, period_percentage, ytd_percentage, cash_flow_category, is_inflow, is_calculated, parent_account_code, extraction_confidence, needs_review, reviewed, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
1	2	1	2	86	-2016	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:04.948151+00	\N
2	2	1	2	86	-2017	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:04.948151+00	\N
3	2	2	5	86	-2016	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:09.477223+00	\N
4	2	2	5	86	-2017	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:09.477223+00	\N
5	3	4	10	86	-2016	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:20.604727+00	\N
6	3	4	10	86	-2017	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:20.604727+00	\N
7	4	7	15	86	-2016	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:32.593346+00	\N
8	4	7	15	86	-2017	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:32.593346+00	\N
9	4	8	18	86	-2016	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:37.541623+00	\N
10	4	8	18	86	-2017	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:37.541623+00	\N
11	5	10	22	86	-2016	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:48.160111+00	\N
12	5	10	22	86	-2017	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:48.160111+00	\N
13	5	11	25	86	-2016	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:53.736343+00	\N
14	5	11	25	86	-2017	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:53.736343+00	\N
15	3	5	28	86	-2016	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:43:00.272202+00	\N
16	3	5	28	86	-2017	Parking Lot	7.00	\N	\N	\N	operating	t	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:43:00.272202+00	\N
\.


--
-- Data for Name: chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.chart_of_accounts (id, account_code, account_name, account_type, category, subcategory, parent_account_code, document_types, is_calculated, calculation_formula, display_order, is_active, created_at, updated_at) FROM stdin;
2	0101-0000	Current Assets	asset	current_asset	\N	0100-0000	{balance_sheet}	f	\N	2	t	2025-11-04 03:38:51.358153+00	\N
3	0122-0000	Cash - Operating	asset	current_asset	cash	0101-0000	{balance_sheet,cash_flow}	f	\N	3	t	2025-11-04 03:38:51.358153+00	\N
4	0123-0000	Cash - Operating II	asset	current_asset	cash	0101-0000	{balance_sheet,cash_flow}	f	\N	4	t	2025-11-04 03:38:51.358153+00	\N
5	0125-0000	Cash - Operating IV-PNC	asset	current_asset	cash	0101-0000	{balance_sheet,cash_flow}	f	\N	5	t	2025-11-04 03:38:51.358153+00	\N
6	0305-0000	A/R Tenants	asset	current_asset	accounts_receivable	0101-0000	{balance_sheet}	f	\N	6	t	2025-11-04 03:38:51.358153+00	\N
7	0306-0000	A/R Other	asset	current_asset	accounts_receivable	0101-0000	{balance_sheet}	f	\N	7	t	2025-11-04 03:38:51.358153+00	\N
9	0500-0000	Property & Equipment	asset	fixed_asset	\N	0100-0000	{balance_sheet}	f	\N	10	t	2025-11-04 03:38:51.358153+00	\N
10	0510-0000	Land	asset	fixed_asset	land	0500-0000	{balance_sheet}	f	\N	11	t	2025-11-04 03:38:51.358153+00	\N
11	0610-0000	Buildings	asset	fixed_asset	buildings	0500-0000	{balance_sheet}	f	\N	12	t	2025-11-04 03:38:51.358153+00	\N
12	0710-0000	5 Year Improvements	asset	fixed_asset	improvements	0500-0000	{balance_sheet}	f	\N	12	t	2025-11-04 03:38:51.358153+00	\N
13	0810-0000	15 Year Improvements	asset	fixed_asset	improvements	0500-0000	{balance_sheet}	f	\N	13	t	2025-11-04 03:38:51.358153+00	\N
14	0815-0000	30 Year - Roof	asset	fixed_asset	improvements	0500-0000	{balance_sheet}	f	\N	14	t	2025-11-04 03:38:51.358153+00	\N
15	0816-0000	30 Year - HVAC	asset	fixed_asset	improvements	0500-0000	{balance_sheet}	f	\N	14	t	2025-11-04 03:38:51.358153+00	\N
16	0910-0000	Other Improvements	asset	fixed_asset	improvements	0500-0000	{balance_sheet}	f	\N	15	t	2025-11-04 03:38:51.358153+00	\N
17	0912-0000	PARKING-LOT	asset	fixed_asset	improvements	0500-0000	{balance_sheet}	f	\N	15	t	2025-11-04 03:38:51.358153+00	\N
18	0950-0000	TI/Current Improvements	asset	fixed_asset	improvements	0500-0000	{balance_sheet}	f	\N	16	t	2025-11-04 03:38:51.358153+00	\N
19	1091-0000	Accum. Depr.-Other Imp.	asset	fixed_asset	accumulated_depreciation	0500-0000	{balance_sheet}	f	\N	19	t	2025-11-04 03:38:51.358153+00	\N
20	1061-0000	Accum. Depr. - Buildings	asset	fixed_asset	accumulated_depreciation	0500-0000	{balance_sheet}	f	\N	17	t	2025-11-04 03:38:51.358153+00	\N
21	1071-0000	Accum. Depr. 5 Year Impr.	asset	fixed_asset	accumulated_depreciation	0500-0000	{balance_sheet}	f	\N	18	t	2025-11-04 03:38:51.358153+00	\N
22	1081-0000	Accum. Depr. 15 Yr Impr.	asset	fixed_asset	accumulated_depreciation	0500-0000	{balance_sheet}	f	\N	19	t	2025-11-04 03:38:51.358153+00	\N
23	1082-0000	Accum. Depr.-Roof2008	asset	fixed_asset	accumulated_depreciation	0500-0000	{balance_sheet}	f	\N	20	t	2025-11-04 03:38:51.358153+00	\N
25	1200-0000	Other Assets	asset	other_asset	\N	0100-0000	{balance_sheet}	f	\N	30	t	2025-11-04 03:38:51.358153+00	\N
26	1210-0000	Deposits	asset	other_asset	deposits	1200-0000	{balance_sheet}	f	\N	31	t	2025-11-04 03:38:51.358153+00	\N
27	1310-0000	Escrow - Property Tax	asset	other_asset	escrow	1200-0000	{balance_sheet}	f	\N	32	t	2025-11-04 03:38:51.358153+00	\N
28	1320-0000	Escrow - Insurance	asset	other_asset	escrow	1200-0000	{balance_sheet}	f	\N	32	t	2025-11-04 03:38:51.358153+00	\N
29	1330-0000	Escrow - TI/LC	asset	other_asset	escrow	1200-0000	{balance_sheet}	f	\N	32	t	2025-11-04 03:38:51.358153+00	\N
30	1340-0000	Escrow - Replacement Reserves	asset	other_asset	escrow	1200-0000	{balance_sheet}	f	\N	32	t	2025-11-04 03:38:51.358153+00	\N
31	1920-0000	Loan Costs	asset	other_asset	deferred_costs	1200-0000	{balance_sheet}	f	\N	33	t	2025-11-04 03:38:51.358153+00	\N
32	1922-0000	Accum. Amortization Loan Costs	asset	other_asset	accumulated_amortization	1200-0000	{balance_sheet}	f	\N	34	t	2025-11-04 03:38:51.358153+00	\N
33	1950-0000	External - Lease Commission	asset	other_asset	deferred_costs	1200-0000	{balance_sheet}	f	\N	35	t	2025-11-04 03:38:51.358153+00	\N
34	1950-5000	Internal - Lease Commission	asset	other_asset	deferred_costs	1200-0000	{balance_sheet}	f	\N	36	t	2025-11-04 03:38:51.358153+00	\N
35	1952-0000	Accum. Amort - TI/LC	asset	other_asset	accumulated_amortization	1200-0000	{balance_sheet}	f	\N	37	t	2025-11-04 03:38:51.358153+00	\N
36	1995-0000	Prepaid Insurance	asset	other_asset	prepaid	1200-0000	{balance_sheet}	f	\N	38	t	2025-11-04 03:38:51.358153+00	\N
40	2001-0000	Current Liabilities	liability	current_liability	\N	2000-0000	{balance_sheet}	f	\N	51	t	2025-11-04 03:38:51.358153+00	\N
41	2030-0000	Accrued Expenses	liability	current_liability	accrued	2001-0000	{balance_sheet}	f	\N	52	t	2025-11-04 03:38:51.358153+00	\N
42	2110-0000	Accounts Payable Trade	liability	current_liability	payables	2001-0000	{balance_sheet}	f	\N	53	t	2025-11-04 03:38:51.358153+00	\N
43	2132-0000	A/P 5Rivers CRE, LLC	liability	current_liability	payables	2001-0000	{balance_sheet}	f	\N	54	t	2025-11-04 03:38:51.358153+00	\N
44	2197-0000	Loans Payable 5Rivers	liability	current_liability	short_term_debt	2001-0000	{balance_sheet}	f	\N	55	t	2025-11-04 03:38:51.358153+00	\N
45	2410-0000	Property Tax Payable	liability	current_liability	payables	2001-0000	{balance_sheet}	f	\N	56	t	2025-11-04 03:38:51.358153+00	\N
46	2510-0000	Rent Received in Advance	liability	current_liability	deferred_revenue	2001-0000	{balance_sheet}	f	\N	57	t	2025-11-04 03:38:51.358153+00	\N
47	2515-0000	A/P Tenant TI/LC Obligations	liability	current_liability	payables	2001-0000	{balance_sheet}	f	\N	58	t	2025-11-04 03:38:51.358153+00	\N
48	2520-0000	Deposit Refundable to Tenant	liability	current_liability	deposits	2001-0000	{balance_sheet}	f	\N	59	t	2025-11-04 03:38:51.358153+00	\N
49	2521-0000	Construction Deposit Refundable	liability	current_liability	deposits	2001-0000	{balance_sheet}	f	\N	60	t	2025-11-04 03:38:51.358153+00	\N
50	2585-0000	A/P Suspense	liability	current_liability	payables	2001-0000	{balance_sheet}	f	\N	60	t	2025-11-04 03:38:51.358153+00	\N
52	2600-0000	Long Term Liabilities	liability	long_term_liability	\N	2000-0000	{balance_sheet}	f	\N	70	t	2025-11-04 03:38:51.358153+00	\N
53	2612-0000	NorthMarq Capital	liability	long_term_liability	mortgage	2600-0000	{balance_sheet}	f	\N	71	t	2025-11-04 03:38:51.358153+00	\N
57	3050-0000	Partners Contribution	equity	capital	contributed_capital	3000-0000	{balance_sheet}	f	\N	81	t	2025-11-04 03:38:51.358153+00	\N
58	3910-0000	Beginning Equity	equity	retained_earnings	beginning_balance	3000-0000	{balance_sheet}	f	\N	82	t	2025-11-04 03:38:51.358153+00	\N
59	3990-0000	Distribution	equity	distributions	owner_distributions	3000-0000	{balance_sheet,cash_flow}	f	\N	83	t	2025-11-04 03:38:51.358153+00	\N
60	3995-0000	Current Period Earnings	equity	net_income	period_earnings	3000-0000	{balance_sheet,income_statement}	t	\N	84	t	2025-11-04 03:38:51.358153+00	\N
64	4010-0000	Base Rentals	income	rental_income	base_rent	4000-0000	{income_statement,cash_flow}	f	\N	101	t	2025-11-04 03:38:51.358153+00	\N
65	4013-0000	Management Fee Income	income	other_income	management_fees	4000-0000	{income_statement}	f	\N	102	t	2025-11-04 03:38:51.358153+00	\N
66	4018-0000	Interest Income	income	other_income	interest	4000-0000	{income_statement,cash_flow}	f	\N	102	t	2025-11-04 03:38:51.358153+00	\N
67	4020-0000	Tax	income	reimbursements	tax_reimbursement	4000-0000	{income_statement,cash_flow}	f	\N	103	t	2025-11-04 03:38:51.358153+00	\N
68	4030-0000	Insurance	income	reimbursements	insurance_reimbursement	4000-0000	{income_statement,cash_flow}	f	\N	104	t	2025-11-04 03:38:51.358153+00	\N
69	4040-0000	CAM	income	reimbursements	cam_reimbursement	4000-0000	{income_statement,cash_flow}	f	\N	105	t	2025-11-04 03:38:51.358153+00	\N
70	4060-0000	Annual Cams	income	reimbursements	cam_reimbursement	4000-0000	{income_statement,cash_flow}	f	\N	106	t	2025-11-04 03:38:51.358153+00	\N
71	4090-0000	Other Income	income	other_income	miscellaneous	4000-0000	{income_statement,cash_flow}	f	\N	107	t	2025-11-04 03:38:51.358153+00	\N
74	5001-0000	Operating Expenses	expense	operating_expense	\N	5000-0000	{income_statement,cash_flow}	f	\N	201	t	2025-11-04 03:38:51.358153+00	\N
75	5010-0000	Property Tax	expense	operating_expense	property_tax	5001-0000	{income_statement,cash_flow}	f	\N	202	t	2025-11-04 03:38:51.358153+00	\N
76	5012-0000	Property Insurance	expense	operating_expense	insurance	5001-0000	{income_statement,cash_flow}	f	\N	203	t	2025-11-04 03:38:51.358153+00	\N
77	5014-0000	Property Tax Savings Consultant	expense	operating_expense	professional_fees	5001-0000	{income_statement,cash_flow}	f	\N	204	t	2025-11-04 03:38:51.358153+00	\N
78	5040-0000	R&M Operating Expenses	expense	operating_expense	\N	5001-0000	{income_statement,cash_flow}	f	\N	210	t	2025-11-04 03:38:51.358153+00	\N
79	5090-0000	Other Operating Expenses	expense	operating_expense	miscellaneous	5001-0000	{income_statement,cash_flow}	f	\N	211	t	2025-11-04 03:38:51.358153+00	\N
80	5100-0000	Utility Expense	expense	operating_expense	utilities	5040-0000	{income_statement,cash_flow}	f	\N	211	t	2025-11-04 03:38:51.358153+00	\N
81	5105-0000	Electricity Service	expense	operating_expense	utilities	5100-0000	{income_statement,cash_flow}	f	\N	212	t	2025-11-04 03:38:51.358153+00	\N
82	5115-0000	Water & Sewer Service	expense	operating_expense	utilities	5100-0000	{income_statement,cash_flow}	f	\N	213	t	2025-11-04 03:38:51.358153+00	\N
83	5125-0000	Trash Service	expense	operating_expense	utilities	5100-0000	{income_statement,cash_flow}	f	\N	214	t	2025-11-04 03:38:51.358153+00	\N
85	5200-0000	Contracted Expense	expense	operating_expense	contracted_services	5040-0000	{income_statement,cash_flow}	f	\N	220	t	2025-11-04 03:38:51.358153+00	\N
86	5210-0000	Contract - Parking Lot Sweeping	expense	operating_expense	contracted_services	5200-0000	{income_statement,cash_flow}	f	\N	221	t	2025-11-04 03:38:51.358153+00	\N
87	5215-0000	Contract - Building Pressure Washing	expense	operating_expense	contracted_services	5200-0000	{income_statement,cash_flow}	f	\N	222	t	2025-11-04 03:38:51.358153+00	\N
88	5220-0000	Contract - Sidewalk Pressure Washing	expense	operating_expense	contracted_services	5200-0000	{income_statement,cash_flow}	f	\N	223	t	2025-11-04 03:38:51.358153+00	\N
89	5225-0000	Contract - Snow Removal & Ice Melt	expense	operating_expense	contracted_services	5200-0000	{income_statement,cash_flow}	f	\N	224	t	2025-11-04 03:38:51.358153+00	\N
90	5230-0000	Contract - Landscaping	expense	operating_expense	contracted_services	5200-0000	{income_statement,cash_flow}	f	\N	225	t	2025-11-04 03:38:51.358153+00	\N
51	2590-0000	Total Current Liabilities	liability	current_liability	total	2001-0000	{balance_sheet}	t	\N	61	t	2025-11-04 03:38:51.358153+00	\N
91	5235-0000	Contract - Janitorial/Portering	expense	operating_expense	contracted_services	5200-0000	{income_statement,cash_flow}	f	\N	226	t	2025-11-04 03:38:51.358153+00	\N
92	5240-0000	Contract - Fire Safety Monitoring	expense	operating_expense	contracted_services	5200-0000	{income_statement,cash_flow}	f	\N	227	t	2025-11-04 03:38:51.358153+00	\N
93	5245-0000	Contract - Pest Control	expense	operating_expense	contracted_services	5200-0000	{income_statement,cash_flow}	f	\N	228	t	2025-11-04 03:38:51.358153+00	\N
95	5300-0000	Repair & Maintenance Operating Expon	expense	operating_expense	repairs_maintenance	5040-0000	{income_statement,cash_flow}	f	\N	230	t	2025-11-04 03:38:51.358153+00	\N
96	5312-0000	R&M - Bulk Trash Removal	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	231	t	2025-11-04 03:38:51.358153+00	\N
97	5314-0000	R&M - Fire Safety Repairs	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	232	t	2025-11-04 03:38:51.358153+00	\N
98	5316-0000	R&M - Fire Sprinkler Inspection	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	233	t	2025-11-04 03:38:51.358153+00	\N
99	5318-0000	R&M - Plumbing	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	234	t	2025-11-04 03:38:51.358153+00	\N
100	5326-0000	R&M - Building Maintenance	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	235	t	2025-11-04 03:38:51.358153+00	\N
101	5332-0000	R&M - Exterior Painting	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	236	t	2025-11-04 03:38:51.358153+00	\N
102	5334-0000	R&M - Parking Lot Repairs	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	237	t	2025-11-04 03:38:51.358153+00	\N
103	5342-0000	R&M - HVAC	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	238	t	2025-11-04 03:38:51.358153+00	\N
104	5356-0000	R&M - Lighting	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	237	t	2025-11-04 03:38:51.358153+00	\N
105	5362-0000	R&M - Roofing Repairs - Minor	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	238	t	2025-11-04 03:38:51.358153+00	\N
106	5364-0000	R&M - Doors/Locks N Keys	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	239	t	2025-11-04 03:38:51.358153+00	\N
107	5366-0000	R&M - Seasonal Decoration	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	240	t	2025-11-04 03:38:51.358153+00	\N
108	5370-0000	R&M - Signage	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	241	t	2025-11-04 03:38:51.358153+00	\N
109	5376-0000	R&M - Misc	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	f	\N	242	t	2025-11-04 03:38:51.358153+00	\N
111	5400-0001	Administration Expense	expense	operating_expense	administrative	5001-0000	{income_statement,cash_flow}	f	\N	250	t	2025-11-04 03:38:51.358153+00	\N
112	5400-0002	Salaries Expense	expense	operating_expense	administrative	5400-0001	{income_statement,cash_flow}	f	\N	251	t	2025-11-04 03:38:51.358153+00	\N
113	5400-0003	Benefits Expense	expense	operating_expense	administrative	5400-0001	{income_statement,cash_flow}	f	\N	252	t	2025-11-04 03:38:51.358153+00	\N
114	5400-0004	Computer & Software Expense	expense	operating_expense	administrative	5400-0001	{income_statement,cash_flow}	f	\N	253	t	2025-11-04 03:38:51.358153+00	\N
115	5435-0000	Meals & Entertainment	expense	operating_expense	administrative	5400-0001	{income_statement,cash_flow}	f	\N	254	t	2025-11-04 03:38:51.358153+00	\N
116	5470-0000	Travel	expense	operating_expense	administrative	5400-0001	{income_statement,cash_flow}	f	\N	255	t	2025-11-04 03:38:51.358153+00	\N
117	5490-0000	Lease Abstracting	expense	operating_expense	administrative	5400-0001	{income_statement,cash_flow}	f	\N	256	t	2025-11-04 03:38:51.358153+00	\N
120	6000-0000	Additional Operating Expenses	expense	operating_expense	\N	5000-0000	{income_statement,cash_flow}	f	\N	300	t	2025-11-04 03:38:51.358153+00	\N
121	6010-0000	Off Site Management	expense	operating_expense	management	6000-0000	{income_statement,cash_flow}	f	\N	301	t	2025-11-04 03:38:51.358153+00	\N
122	6020-0000	Professional Fees	expense	operating_expense	professional_fees	6000-0000	{income_statement,cash_flow}	f	\N	302	t	2025-11-04 03:38:51.358153+00	\N
123	6020-5000	Accounting Fee	expense	operating_expense	professional_fees	6000-0000	{income_statement,cash_flow}	f	\N	303	t	2025-11-04 03:38:51.358153+00	\N
124	6020-6000	Asset Management Fee	expense	operating_expense	professional_fees	6000-0000	{income_statement,cash_flow}	f	\N	304	t	2025-11-04 03:38:51.358153+00	\N
125	6020-7000	CMF-Construction Management Fee	expense	operating_expense	professional_fees	6000-0000	{income_statement,cash_flow}	f	\N	305	t	2025-11-04 03:38:51.358153+00	\N
126	6022-0000	Legal Fees / SOS Fee	expense	operating_expense	professional_fees	6000-0000	{income_statement,cash_flow}	f	\N	306	t	2025-11-04 03:38:51.358153+00	\N
127	6024-0000	Bank Charges	expense	operating_expense	banking	6000-0000	{income_statement,cash_flow}	f	\N	307	t	2025-11-04 03:38:51.358153+00	\N
128	6040-0000	LL - Expense	expense	operating_expense	landlord_expense	6000-0000	{income_statement,cash_flow}	f	\N	308	t	2025-11-04 03:38:51.358153+00	\N
129	6065-0000	LL-Site Map	expense	operating_expense	landlord_expense	6040-0000	{income_statement,cash_flow}	f	\N	309	t	2025-11-04 03:38:51.358153+00	\N
135	7010-0000	Mortgage Interest	expense	non_operating	interest	7000-0000	{income_statement,cash_flow}	f	\N	401	t	2025-11-04 03:38:51.358153+00	\N
136	7020-0000	Depreciation	expense	non_operating	depreciation	7000-0000	{income_statement}	f	\N	402	t	2025-11-04 03:38:51.358153+00	\N
137	7030-0000	Amortization	expense	non_operating	amortization	7000-0000	{income_statement}	f	\N	403	t	2025-11-04 03:38:51.358153+00	\N
1	0100-0000	ASSETS	asset	header	\N	\N	{balance_sheet}	t	\N	1	t	2025-11-04 03:38:51.358153+00	\N
8	0499-9000	Total Current Assets	asset	current_asset	total	0101-0000	{balance_sheet}	t	\N	8	t	2025-11-04 03:38:51.358153+00	\N
24	1099-0000	Total Property & Equipment	asset	fixed_asset	total	0500-0000	{balance_sheet}	t	\N	21	t	2025-11-04 03:38:51.358153+00	\N
37	1998-0000	Total Other Assets	asset	other_asset	total	1200-0000	{balance_sheet}	t	\N	39	t	2025-11-04 03:38:51.358153+00	\N
38	1999-0000	TOTAL ASSETS	asset	total	total	0100-0000	{balance_sheet}	t	\N	40	t	2025-11-04 03:38:51.358153+00	\N
39	2000-0000	LIABILITIES	liability	header	\N	\N	{balance_sheet}	t	\N	50	t	2025-11-04 03:38:51.358153+00	\N
54	2900-0000	Total Long Term Liabilities	liability	long_term_liability	total	2600-0000	{balance_sheet}	t	\N	72	t	2025-11-04 03:38:51.358153+00	\N
55	2999-0000	TOTAL LIABILITIES	liability	total	total	2000-0000	{balance_sheet}	t	\N	73	t	2025-11-04 03:38:51.358153+00	\N
56	3000-0000	CAPITAL	equity	header	\N	\N	{balance_sheet}	t	\N	80	t	2025-11-04 03:38:51.358153+00	\N
61	3999-0000	TOTAL CAPITAL	equity	total	total	3000-0000	{balance_sheet}	t	\N	85	t	2025-11-04 03:38:51.358153+00	\N
62	3999-9000	TOTAL LIABILITIES & CAPITAL	equity	total	total	\N	{balance_sheet}	t	\N	86	t	2025-11-04 03:38:51.358153+00	\N
63	4000-0000	INCOME	income	header	\N	\N	{income_statement,cash_flow}	t	\N	100	t	2025-11-04 03:38:51.358153+00	\N
72	4990-0000	TOTAL INCOME	income	total	total	4000-0000	{income_statement,cash_flow}	t	\N	108	t	2025-11-04 03:38:51.358153+00	\N
73	5000-0000	EXPENSES	expense	header	\N	\N	{income_statement,cash_flow}	t	\N	200	t	2025-11-04 03:38:51.358153+00	\N
84	5199-0000	Total Utility Expense	expense	operating_expense	utilities	5100-0000	{income_statement,cash_flow}	t	\N	215	t	2025-11-04 03:38:51.358153+00	\N
94	5299-0000	Total Contracted Expenses	expense	operating_expense	contracted_services	5200-0000	{income_statement,cash_flow}	t	\N	229	t	2025-11-04 03:38:51.358153+00	\N
110	5399-0000	Total R&M Operating Expenses	expense	operating_expense	repairs_maintenance	5300-0000	{income_statement,cash_flow}	t	\N	243	t	2025-11-04 03:38:51.358153+00	\N
118	5499-0000	Total Administration Expense	expense	operating_expense	administrative	5400-0001	{income_statement,cash_flow}	t	\N	257	t	2025-11-04 03:38:51.358153+00	\N
119	5990-0000	Total Operating Expenses	expense	operating_expense	total	5001-0000	{income_statement,cash_flow}	t	\N	258	t	2025-11-04 03:38:51.358153+00	\N
130	6069-0000	Total LL Expense	expense	operating_expense	landlord_expense	6040-0000	{income_statement,cash_flow}	t	\N	310	t	2025-11-04 03:38:51.358153+00	\N
131	6190-0000	Total Additional Operating Expenses	expense	operating_expense	total	6000-0000	{income_statement,cash_flow}	t	\N	311	t	2025-11-04 03:38:51.358153+00	\N
132	6199-0000	TOTAL EXPENSES	expense	total	total	5000-0000	{income_statement,cash_flow}	t	\N	312	t	2025-11-04 03:38:51.358153+00	\N
133	6299-0000	NET OPERATING INCOME	income	net_operating_income	noi	\N	{income_statement}	t	\N	313	t	2025-11-04 03:38:51.358153+00	\N
134	7000-0000	Other Income/Expenses	expense	non_operating	\N	\N	{income_statement}	t	\N	400	t	2025-11-04 03:38:51.358153+00	\N
138	7090-0000	Total Other Income/Expense	expense	non_operating	total	7000-0000	{income_statement}	t	\N	404	t	2025-11-04 03:38:51.358153+00	\N
139	9090-0000	NET INCOME	income	net_income	net_income	\N	{income_statement,balance_sheet}	t	\N	500	t	2025-11-04 03:38:51.358153+00	\N
\.


--
-- Data for Name: document_uploads; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.document_uploads (id, property_id, period_id, document_type, file_name, file_path, file_hash, file_size_bytes, upload_date, uploaded_by, extraction_status, extraction_started_at, extraction_completed_at, extraction_id, version, is_active, notes) FROM stdin;
8	3	4	balance_sheet	Hammond Aire 2023 Balance Sheet.pdf	HMND001/2023/12/balance_sheet_20251104_032252.pdf	d2a57acc42ae11e3d827351c5a8235d1	3568	2025-11-04 03:22:52.328977+00	\N	completed	2025-11-04 03:50:33.980382+00	2025-11-04 03:50:37.680404+00	40	1	t	\N
4	2	2	balance_sheet	ESP 2024 Balance Sheet.pdf	ESP001/2024/12/balance_sheet_20251104_031906.pdf	15a5bbadb72da091f20e00d6ec3cf1ec	8358	2025-11-04 03:19:06.449345+00	\N	completed	2025-11-04 03:50:33.947962+00	2025-11-04 03:50:38.610202+00	39	1	t	\N
11	3	5	balance_sheet	Hammond Aire2024 Balance Sheet.pdf	HMND001/2024/12/balance_sheet_20251104_032253.pdf	ad68ed4a7127d403a01c493bfa3287b3	8387	2025-11-04 03:22:53.036547+00	\N	completed	2025-11-04 03:50:37.952676+00	2025-11-04 03:50:39.795212+00	41	1	t	\N
1	2	1	balance_sheet	ESP 2023 Balance Sheet.pdf	ESP001/2023/12/balance_sheet_20251104_031259.pdf	a4050400f386bd451cf1a8fd901f9f67	3585	2025-11-04 03:12:59.786183+00	\N	completed	2025-11-04 03:50:38.711664+00	2025-11-04 03:50:40.615442+00	42	1	t	\N
3	2	1	income_statement	ESP 2023 Income Statement.pdf	ESP001/2023/12/income_statement_20251104_031704.pdf	209d5e2c237167da7eea1fe635cc011e	8684	2025-11-04 03:17:04.48927+00	\N	completed	2025-11-04 03:42:02.500464+00	2025-11-04 03:42:06.036306+00	3	1	t	\N
28	3	5	cash_flow	Hammond Aire 2024 Cash Flow Statement.pdf	HMND001/2024/12/cash_flow_20251104_032332.pdf	26070f40babf1dd322391c3ccaa20562	25785	2025-11-04 03:23:32.959392+00	\N	completed	2025-11-04 03:42:59.199004+00	2025-11-04 03:43:03.024834+00	29	1	t	\N
2	2	1	cash_flow	ESP 2023 Cash Flow Statement.pdf	ESP001/2023/12/cash_flow_20251104_031502.pdf	a0ef1ce18c3493be41cbbeb27a350b14	25545	2025-11-04 03:15:02.447878+00	\N	completed	2025-11-04 03:42:02.284034+00	2025-11-04 03:42:11.662095+00	4	1	t	\N
5	2	2	cash_flow	ESP 2024 Cash Flow Statement.pdf	ESP001/2024/12/cash_flow_20251104_032108.pdf	6072cbde347533acff38a27e5341d929	25569	2025-11-04 03:21:08.47514+00	\N	completed	2025-11-04 03:42:08.611983+00	2025-11-04 03:42:16.48922+00	6	1	t	\N
6	2	2	income_statement	ESP 2024 Income Statement.pdf	ESP001/2024/12/income_statement_20251104_032251.pdf	5bd3dc53da90ec4dc46f4dea1fc6e626	14007	2025-11-04 03:22:51.537996+00	\N	completed	2025-11-04 03:42:11.753898+00	2025-11-04 03:42:16.616105+00	7	1	t	\N
9	3	4	income_statement	Hammond Aire 2023 Income Statement.pdf	HMND001/2023/12/income_statement_20251104_032252.pdf	bf97a38dbc6cd6c0d0f56b3debf9311d	8812	2025-11-04 03:22:52.539929+00	\N	completed	2025-11-04 03:42:18.012202+00	2025-11-04 03:42:19.678273+00	10	1	t	\N
7	2	3	rent_roll	ESP Roll April 2025.pdf	ESP001/2025/04/rent_roll_20251104_032252.pdf	a626acd787d1765b817a025a9722dbe3	41380	2025-11-04 03:22:52.109569+00	\N	completed	2025-11-04 03:42:16.588153+00	2025-11-04 03:42:21.126952+00	9	1	t	\N
10	3	4	cash_flow	Hammond Aire 2023 Cash Flow Statement.pdf	HMND001/2023/12/cash_flow_20251104_032252.pdf	9094bac01d2fa1c402dd79f546824d4a	25513	2025-11-04 03:22:52.789062+00	\N	completed	2025-11-04 03:42:19.792234+00	2025-11-04 03:42:25.889769+00	11	1	t	\N
14	4	7	income_statement	TCSH 2023 Income Statement.pdf	TCSH001/2023/12/income_statement_20251104_032254.pdf	ff8d69acf870d7cf03c5ac36c801c6d3	8207	2025-11-04 03:22:54.041775+00	\N	completed	2025-11-04 03:42:28.313512+00	2025-11-04 03:42:30.401552+00	15	1	t	\N
12	3	6	rent_roll	Hammond Rent Roll April 2025.pdf	HMND001/2025/04/rent_roll_20251104_032253.pdf	933ef4c2a07ec2bb7e8b800098f00f14	60419	2025-11-04 03:22:53.455818+00	\N	completed	2025-11-04 03:42:23.755126+00	2025-11-04 03:42:34.520762+00	13	1	t	\N
15	4	7	cash_flow	TCSH 2023 Cash FLow Statement.pdf	TCSH001/2023/12/cash_flow_20251104_032254.pdf	5b311264b8520d71e788d7ec09a8c511	25203	2025-11-04 03:22:54.241152+00	\N	completed	2025-11-04 03:42:30.581276+00	2025-11-04 03:42:36.667219+00	16	1	t	\N
17	4	8	income_statement	TCSH 2024 Income Statement.pdf	TCSH001/2024/12/income_statement_20251104_032254.pdf	7234d687c3ccebe38b07d38e980df3e2	7599	2025-11-04 03:22:54.696322+00	\N	completed	2025-11-04 03:42:36.188701+00	2025-11-04 03:42:40.690888+00	18	1	t	\N
18	4	8	cash_flow	TCSH 2024 Cash Flow Statement.pdf	TCSH001/2024/12/cash_flow_20251104_032254.pdf	95b42632da1f0ddedd86eab7ae8d5c11	25388	2025-11-04 03:22:54.944407+00	\N	completed	2025-11-04 03:42:36.741379+00	2025-11-04 03:42:41.793651+00	19	1	t	\N
21	5	10	income_statement	Wendover Commons 2023 Income Statement.pdf	WEND001/2023/12/income_statement_20251104_032255.pdf	15696323808739bfaf170e959c745690	7785	2025-11-04 03:22:55.82238+00	\N	completed	2025-11-04 03:42:45.693618+00	2025-11-04 03:42:47.460514+00	22	1	t	\N
19	4	9	rent_roll	TCSH Rent Roll April 2025.pdf	TCSH001/2025/04/rent_roll_20251104_032255.pdf	cff11b662d18b8b504554e22bc691276	61660	2025-11-04 03:22:55.285312+00	\N	completed	2025-11-04 03:42:42.302379+00	2025-11-04 03:42:51.625149+00	20	1	t	\N
22	5	10	cash_flow	Wendover Commons 2023 Cash Flow Statement.pdf	WEND001/2023/12/cash_flow_20251104_032256.pdf	4c16a81f10f4a901f816315eedc41161	25018	2025-11-04 03:22:56.047246+00	\N	completed	2025-11-04 03:42:47.591685+00	2025-11-04 03:42:51.800032+00	23	1	t	\N
24	5	11	income_statement	Wendover Commons 2024 Income Statement.pdf	WEND001/2024/12/income_statement_20251104_032256.pdf	6268cba12fab48ad7d9112158be62688	7531	2025-11-04 03:22:56.621295+00	\N	completed	2025-11-04 03:42:51.922497+00	2025-11-04 03:42:53.350475+00	25	1	t	\N
25	5	11	cash_flow	Wendover Commons 2024 Cash Flow Statement.pdf	WEND001/2024/12/cash_flow_20251104_032256.pdf	f8ce93aca4295d1c052db5354ca1869e	25263	2025-11-04 03:22:56.844148+00	\N	completed	2025-11-04 03:42:53.109249+00	2025-11-04 03:42:56.115662+00	26	1	t	\N
26	5	12	rent_roll	Wendover Rent Roll April 2025.pdf	WEND001/2025/04/rent_roll_20251104_032257.pdf	5e264c38b7c52ef67eeac3658f0d69e6	29636	2025-11-04 03:22:57.202837+00	\N	completed	2025-11-04 03:42:53.432505+00	2025-11-04 03:42:58.892046+00	27	1	t	\N
27	3	5	income_statement	Hammond Aire 2024 Income Statement.pdf	HMND001/2024/12/income_statement_20251104_032325.pdf	270e29c788951852b4d1efd93b533ab5	14164	2025-11-04 03:23:25.539064+00	\N	completed	2025-11-04 03:42:56.200359+00	2025-11-04 03:43:00.148733+00	28	1	t	\N
13	4	7	balance_sheet	TCSH 2023 Balance Sheet.pdf	TCSH001/2023/12/balance_sheet_20251104_032253.pdf	4decd7e9779c9969fe5631c083dea106	3686	2025-11-04 03:22:53.744155+00	\N	completed	2025-11-04 03:50:39.988154+00	2025-11-04 03:50:41.289699+00	43	1	t	\N
16	4	8	balance_sheet	TCSH 2024 Balance Sheet.pdf	TCSH001/2024/12/balance_sheet_20251104_032254.pdf	a8203d57fe9d34fc1a13e7de88105e10	3764	2025-11-04 03:22:54.535014+00	\N	completed	2025-11-04 03:50:40.923742+00	2025-11-04 03:50:43.421521+00	44	1	t	\N
20	5	10	balance_sheet	Wendover Commons 2023 Balance Sheet.pdf	WEND001/2023/12/balance_sheet_20251104_032255.pdf	f90c162b4fc7683861d96a526c8db467	3359	2025-11-04 03:22:55.606707+00	\N	completed	2025-11-04 03:50:41.534289+00	2025-11-04 03:50:45.244878+00	45	1	t	\N
23	5	11	balance_sheet	Wendover Commons 2024 Balance Sheet.pdf	WEND001/2024/12/balance_sheet_20251104_032256.pdf	a1bb225e32356b98133686ab6b84a2d5	3595	2025-11-04 03:22:56.401247+00	\N	completed	2025-11-04 03:50:43.697271+00	2025-11-04 03:50:45.910445+00	46	1	t	\N
\.


--
-- Data for Name: extraction_logs; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.extraction_logs (id, filename, file_size, file_hash, document_type, total_pages, strategy_used, engines_used, primary_engine, confidence_score, quality_level, passed_checks, total_checks, processing_time_seconds, extraction_timestamp, validation_issues, validation_warnings, recommendations, extracted_text, text_preview, total_words, total_chars, tables_found, images_found, needs_review, reviewed, reviewed_by, reviewed_at, review_notes, custom_metadata, created_at, updated_at) FROM stdin;
1	ESP 2023 Balance Sheet.pdf	3585	a4050400f386bd451cf1a8fd901f9f67	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	1.64	2025-11-04 03:38:05.172495+00	["High gibberish ratio: 17.57%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n114,890.87\n0123-0000\n Cash - Operating II\n6,504.46\n0210-0000\n Accounts Receivables - Trade\n-56,028.54\n0305-0000\n A/R Tenants\n216,612.99\n0306-0000\nA/R Other\n200,000.00\n0499-9000\n Total Current Assets\n481,979.78\n0500-0000\n Property & Equipment\n0510-0000\n Land\n3,100,438.76\n0610-0000\n Buildings\n21,912,631.00\n0710-0000\n 5 Year Improvements\n1,016,850.00\n0810-0000\n 15 Year Improvements\n3,222,949.65\n0815-0000\n 30 Yea	296	2428	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1213.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:38:05.172495+00	\N
2	ESP 2023 Balance Sheet.pdf	3585	a4050400f386bd451cf1a8fd901f9f67	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.21	2025-11-04 03:39:31.325491+00	["High gibberish ratio: 17.57%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n114,890.87\n0123-0000\n Cash - Operating II\n6,504.46\n0210-0000\n Accounts Receivables - Trade\n-56,028.54\n0305-0000\n A/R Tenants\n216,612.99\n0306-0000\nA/R Other\n200,000.00\n0499-9000\n Total Current Assets\n481,979.78\n0500-0000\n Property & Equipment\n0510-0000\n Land\n3,100,438.76\n0610-0000\n Buildings\n21,912,631.00\n0710-0000\n 5 Year Improvements\n1,016,850.00\n0810-0000\n 15 Year Improvements\n3,222,949.65\n0815-0000\n 30 Yea	296	2428	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1213.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:39:31.325491+00	\N
3	ESP 2023 Income Statement.pdf	8684	209d5e2c237167da7eea1fe635cc011e	digital	3	auto	["pymupdf"]	pymupdf	100	excellent	10	10	1.91	2025-11-04 03:42:02.62385+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n4000-0000\n INCOME\n4010-0000\n Base Rentals\n229,422.31\n89.18\n2,768,568.46\n81.43\n4013-0000\nManagement Fee Income\n0.00\n0.00\n97.78\n0.00\n4018-0000\nInterest Income\n561.75\n0.22\n561.75\n0.02\n4020-0000\n Tax\n5,770.07\n2.24\n68,793.27\n2.02\n4030-0000\n Insurance\n4,811.99\n1.87\n57,110.05\n1.68\n4040-0000\n CAM\n24,202.38\n9.41\n292,227.22\n8.60\n4050-0000\n Percentage Rent\n0.00\n0.00\n59,124.03\n1.74\n4060-0000\n Annual Cams\n-8,089.61\n-3.14\n150,962.44\n4.44\n4090-0000\n Other Income\n0.00\n0.00\n1,50	752	5368	0	0	f	f	\N	\N	\N	{"total_pages": 3, "avg_text_per_page": 1788.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:02.62385+00	\N
4	ESP 2023 Cash Flow Statement.pdf	25545	a0ef1ce18c3493be41cbbeb27a350b14	digital	9	auto	["pymupdf"]	pymupdf	100	excellent	10	10	2.46	2025-11-04 03:42:02.319681+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n UN-Used - FUTURE Use\n0.00\n0.00\n0.00\n0.00\n INCOME\n Base Rentals\n2,768,568.46\n81.43\n2,768,568.46\n81.43\n Holdover Rent\n0.00\n0.00\n0.00\n0.00\n Free Rent\n0.00\n0.00\n0.00\n0.00\n Co-Tenancy Rent Reduction\n0.00\n0.00\n0.00\n0.00\n Bad Debt Expense\n0.00\n0.00\n0.00\n0.00\nManagement Fee Income\n97.78\n0.00\n97.78\n0.00\nAdmin Fee Income\n0.00\n0.00\n0.00\n0.00\nLeasing Commission Income\n0.00\n0.00\n0.00\n0.00\nConstruction Mgt Fee Income\n0.00\n0.00\n0.00\n0.00\nAccounting Fee Income\n0.00\n0.00\n0.00\n0	3026	18625	0	0	f	f	\N	\N	\N	{"total_pages": 9, "avg_text_per_page": 2206.8, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:02.319681+00	\N
5	ESP 2024 Balance Sheet.pdf	8358	15a5bbadb72da091f20e00d6ec3cf1ec	digital	5	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.33	2025-11-04 03:42:06.191355+00	[]	[]	["Extraction quality is high - safe to use"]	\N	Current Balance\n ASSETS\n Current Assets\n Cash on Hand\n0.00\n Cash - Savings\n0.00\n Cash - Operating\n-1,080.00\n Cash - Operating II\n6,504.46\n Cash - Operating III WF\n0.00\n Cash - Operating IV-PNC\n365,638.38\n Cash - Depository - PNC\n0.00\n Cash - Escrow - PNC\n0.00\n Non-Cash (Adjustments)\n0.00\n Accounts Receivables - Trade\n-59,213.38\n A/R Tenants\n210,365.06\n A/R - Allowance for Doubtful\n0.00\nA/R Other\n0.00\n Title Escrow/Lender App\n0.00\n A/R Reserve Escrow BNY Mellon [TAFT]\n0.00\n A/R Frayser Village\n0.	994	6509	0	0	f	f	\N	\N	\N	{"total_pages": 5, "avg_text_per_page": 1300.2, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:06.191355+00	\N
6	ESP 2024 Cash Flow Statement.pdf	25569	6072cbde347533acff38a27e5341d929	digital	9	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.72	2025-11-04 03:42:08.696892+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n UN-Used - FUTURE Use\n0.00\n0.00\n0.00\n0.00\n INCOME\n Base Rentals\n2,726,029.62\n79.55\n2,726,029.62\n79.55\n Holdover Rent\n0.00\n0.00\n0.00\n0.00\n Free Rent\n-5,333.33\n-0.16\n-5,333.33\n-0.16\n Co-Tenancy Rent Reduction\n0.00\n0.00\n0.00\n0.00\n Bad Debt Expense\n0.00\n0.00\n0.00\n0.00\nManagement Fee Income\n0.00\n0.00\n0.00\n0.00\nAdmin Fee Income\n0.00\n0.00\n0.00\n0.00\nLeasing Commission Income\n0.00\n0.00\n0.00\n0.00\nConstruction Mgt Fee Income\n0.00\n0.00\n0.00\n0.00\nAccounting Fee Income\n0.00\n0	3040	18675	0	0	f	f	\N	\N	\N	{"total_pages": 9, "avg_text_per_page": 2196.4, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:08.696892+00	\N
7	ESP 2024 Income Statement.pdf	14007	5bd3dc53da90ec4dc46f4dea1fc6e626	digital	5	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.59	2025-11-04 03:42:11.76919+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n UN-Used - FUTURE Use\n0.00\n0.00\n0.00\n0.00\n INCOME\n Base Rentals\n2,726,029.62\n79.55\n2,726,029.62\n79.55\n Holdover Rent\n0.00\n0.00\n0.00\n0.00\n Free Rent\n-5,333.33\n-0.16\n-5,333.33\n-0.16\n Co-Tenancy Rent Reduction\n0.00\n0.00\n0.00\n0.00\n Bad Debt Expense\n0.00\n0.00\n0.00\n0.00\nManagement Fee Income\n0.00\n0.00\n0.00\n0.00\nAdmin Fee Income\n0.00\n0.00\n0.00\n0.00\nLeasing Commission Income\n0.00\n0.00\n0.00\n0.00\nConstruction Mgt Fee Income\n0.00\n0.00\n0.00\n0.00\nAccounting Fee Income\n0.00\n0	1565	9891	0	0	f	f	\N	\N	\N	{"total_pages": 5, "avg_text_per_page": 1976.6, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:11.76919+00	\N
8	Hammond Aire 2023 Balance Sheet.pdf	3568	d2a57acc42ae11e3d827351c5a8235d1	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.36	2025-11-04 03:42:16.72655+00	["High gibberish ratio: 17.24%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n129,504.76\n0123-0000\n Cash - Operating II\n5,000.00\n0305-0000\n A/R Tenants\n288,583.04\n0347-0000\n Escrow - Other\n281,295.46\n0499-9000\n Total Current Assets\n704,383.26\n0500-0000\n Property & Equipment\n0510-0000\n Land\n6,000,000.00\n0610-0000\n Buildings\n24,746,662.00\n0710-0000\n 5 Year Improvements\n2,404,328.00\n0810-0000\n 15 Year Improvements\n7,050,280.00\n1061-0000\n Accum. Depr. - Buildings\n-2,485,241.70\n1071-0000\n A	290	2395	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1196.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:16.72655+00	\N
9	ESP Roll April 2025.pdf	41380	a626acd787d1765b817a025a9722dbe3	digital	4	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.98	2025-11-04 03:42:16.607188+00	[]	[]	["Extraction quality is high - safe to use"]	\N	Property\nUnit(s)\nLease\nLease Type\nArea\nLease From\nLease To\nTerm\nTenancy\nYears\nMonthly Rent\nMonthly\nRent/Area\nAnnual\nRent\nAnnual\nRent/Area\nAnnual\nRec./Area\nAnnual\nMisc/Area\nSecurity\nDeposit\nReceived\nLOC\nAmount/\nBank\nGuarantee\nEastern Shore Plaza\n(esp)\nThe Lamar\nCompanies\n(t0000366)\nRetail Gross\n0.00\n04/05/2005\n12/31/2025\n249\n20.08\n0.00\n0.00\n0.00\n0.00\n0.00\n0.00\n0.00\n0.00\nGross Rent\n0.00\n0.00\n0.00\n0.00\nEastern Shore Plaza\n(esp)\n106\nCEJR Health\nServices, LLC\n(t0000490)\nRetail NNN\n1,800.00\n03/05/2020	1052	7018	0	0	f	f	\N	\N	\N	{"total_pages": 4, "avg_text_per_page": 1753.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 1, "has_text_layer": true}	2025-11-04 03:42:16.607188+00	\N
10	Hammond Aire 2023 Income Statement.pdf	8812	bf97a38dbc6cd6c0d0f56b3debf9311d	digital	3	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.31	2025-11-04 03:42:18.034123+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n4000-0000\n INCOME\n4010-0000\n Base Rentals\n305,887.14\n82.30\n3,681,177.55\n82.73\n4013-0000\nManagement Fee Income\n1,905.43\n0.51\n12,261.62\n0.28\n4020-0000\n Tax\n4,736.90\n1.27\n57,612.51\n1.29\n4030-0000\n Insurance\n563.20\n0.15\n7,118.40\n0.16\n4040-0000\n CAM\n33,264.42\n8.95\n402,559.89\n9.05\n4050-0000\n Percentage Rent\n0.00\n0.00\n46,519.24\n1.05\n4055-0000\n Utilities Reimbursement\n350.00\n0.09\n2,450.00\n0.06\n4060-0000\n Annual Cams\n0.00\n0.00\n183,114.00\n4.12\n4090-0000\n Other Income\n24,6	774	5558	0	0	f	f	\N	\N	\N	{"total_pages": 3, "avg_text_per_page": 1851.33, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:18.034123+00	\N
11	Hammond Aire 2023 Cash Flow Statement.pdf	25513	9094bac01d2fa1c402dd79f546824d4a	digital	9	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.72	2025-11-04 03:42:19.808318+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n UN-Used - FUTURE Use\n0.00\n0.00\n0.00\n0.00\n INCOME\n Base Rentals\n3,681,177.55\n82.73\n3,681,177.55\n82.73\n Holdover Rent\n0.00\n0.00\n0.00\n0.00\n Free Rent\n0.00\n0.00\n0.00\n0.00\n Co-Tenancy Rent Reduction\n0.00\n0.00\n0.00\n0.00\n Bad Debt Expense\n0.00\n0.00\n0.00\n0.00\nManagement Fee Income\n12,261.62\n0.28\n12,261.62\n0.28\nAdmin Fee Income\n0.00\n0.00\n0.00\n0.00\nLeasing Commission Income\n0.00\n0.00\n0.00\n0.00\nConstruction Mgt Fee Income\n0.00\n0.00\n0.00\n0.00\nAccounting Fee Income\n0.00\n0.0	3026	18669	0	0	f	f	\N	\N	\N	{"total_pages": 9, "avg_text_per_page": 2207.2, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:19.808318+00	\N
13	Hammond Rent Roll April 2025.pdf	60419	933ef4c2a07ec2bb7e8b800098f00f14	digital	6	auto	["pymupdf"]	pymupdf	100	excellent	10	10	1.17	2025-11-04 03:42:23.889275+00	[]	[]	["Extraction quality is high - safe to use"]	\N	Property\nUnit(s)\nLease\nLease Type\nArea\nLease From\nLease To\nTerm\nTenancy\nYears\nMonthly Rent\nMonthly\nRent/Area\nAnnual\nRent\nAnnual\nRent/Area\nAnnual\nRec./Area\nAnnual\nMisc/Area\nSecurity\nDeposit\nReceived\nLOC\nAmount/\nBank\nGuarantee\nHammond Aire Plaza\n(hmnd)\n001\nHaison Lam and\nHuong Thi-Bich\nNguyen/ Elite\nNails (t0000507)\nRetail NNN\n703.00\n04/17/2004\n02/29/2028\n287\n21.08\n2,167.58\n3.08\n26,010.96\n37.00\n4.96\n1.48\n1,661.42\n0.00\nGross Rent\n2,458.15\n3.49\n29,497.80\n41.96\nHammond Aire Plaza\n(hmnd)\n002-A\nSubway 	1578	10609	0	0	f	f	\N	\N	\N	{"total_pages": 6, "avg_text_per_page": 1967.2, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 1, "has_text_layer": true}	2025-11-04 03:42:23.889275+00	\N
14	TCSH 2023 Balance Sheet.pdf	3686	4decd7e9779c9969fe5631c083dea106	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.54	2025-11-04 03:42:26.050016+00	["High gibberish ratio: 17.49%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n566,871.52\n0305-0000\n A/R Tenants\n362,040.37\n0306-0000\nA/R Other\n7,252.23\n0499-9000\n Total Current Assets\n936,164.12\n0500-0000\n Property & Equipment\n0510-0000\n Land\n5,145,300.00\n0610-0000\n Buildings\n24,092,306.22\n0710-0000\n 5 Year Improvements\n1,112,642.00\n0810-0000\n 15 Year Improvements\n5,956,169.06\n0815-0000\n 30 Year - Roof\n11,972.09\n0910-0000\n Other Improvements\n542,500.00\n0912-0000\n PARKING-LOT\n8,619.54\n1	303	2495	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1246.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:26.050016+00	\N
18	TCSH 2024 Income Statement.pdf	7599	7234d687c3ccebe38b07d38e980df3e2	digital	3	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.57	2025-11-04 03:42:36.212814+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n4000-0000\n INCOME\n4010-0000\n Base Rentals\n321,799.28\n87.22\n3,828,576.02\n86.71\n4018-0000\nInterest Income\n0.00\n0.00\n409.85\n0.01\n4020-0000\n Tax\n15,073.46\n4.09\n170,488.99\n3.86\n4030-0000\n Insurance\n2,401.25\n0.65\n27,393.89\n0.62\n4040-0000\n CAM\n27,104.70\n7.35\n400,534.92\n9.07\n4060-0000\n Annual Cams\n0.00\n0.00\n-14,602.37\n-0.33\n4090-0000\n Other Income\n2,592.19\n0.70\n2,494.96\n0.06\n4990-0000\n TOTAL INCOME\n368,970.88\n100.00\n4,415,296.26\n100.00\n5000-0000\n EXPENSES\n5001-0000\n Ope	607	4353	0	0	f	f	\N	\N	\N	{"total_pages": 3, "avg_text_per_page": 1449.67, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:36.212814+00	\N
20	TCSH Rent Roll April 2025.pdf	61660	cff11b662d18b8b504554e22bc691276	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.51	2025-11-04 03:42:42.346759+00	["High gibberish ratio: 17.72%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n246,111.90\n0305-0000\n A/R Tenants\n20,137.51\n0306-0000\nA/R Other\n140,132.00\n0499-9000\n Total Current Assets\n406,381.41\n0500-0000\n Property & Equipment\n0510-0000\n Land\n4,024,000.00\n0610-0000\n Buildings\n25,326,000.00\n0810-0000\n 15 Year Improvements\n5,960.00\n0815-0000\n 30 Year - Roof\n1,918.22\n0912-0000\n PARKING-LOT\n250.00\n1061-0000\n Accum. Depr. - Buildings\n-1,784,008.00\n1071-0000\n Accum. Depr. 5 Year Impr.\n-2,49	254	2106	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1052.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:42.346759+00	\N
22	Wendover Commons 2023 Income Statement.pdf	7785	15696323808739bfaf170e959c745690	digital	3	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.31	2025-11-04 03:42:45.739387+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n4000-0000\n INCOME\n4010-0000\n Base Rentals\n2,547,874.51\n78.85\n2,547,874.51\n78.85\n4013-0000\nManagement Fee Income\n32.10\n0.00\n32.10\n0.00\n4020-0000\n Tax\n177,117.69\n5.48\n177,117.69\n5.48\n4030-0000\n Insurance\n34,701.15\n1.07\n34,701.15\n1.07\n4040-0000\n CAM\n182,154.73\n5.64\n182,154.73\n5.64\n4056-0000\nTermination Fee Income\n10,605.00\n0.33\n10,605.00\n0.33\n4060-0000\n Annual Cams\n273,399.15\n8.46\n273,399.15\n8.46\n4090-0000\n Other Income\n2,975.01\n0.09\n2,975.01\n0.09\n4091-0000\nEnd of 	668	4877	0	0	f	f	\N	\N	\N	{"total_pages": 3, "avg_text_per_page": 1624.33, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:45.739387+00	\N
12	Hammond Aire2024 Balance Sheet.pdf	8387	ad68ed4a7127d403a01c493bfa3287b3	digital	5	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.42	2025-11-04 03:42:21.278221+00	[]	[]	["Extraction quality is high - safe to use"]	\N	Current Balance\n ASSETS\n Current Assets\n Cash on Hand\n0.00\n Cash - Savings\n0.00\n Cash - Operating\n-3,549.10\n Cash - Operating II\n5,000.00\n Cash - Operating III WF\n0.00\n Cash - Operating IV-PNC\n234,349.36\n Cash - Depository - PNC\n0.00\n Cash - Escrow - PNC\n0.00\n Non-Cash (Adjustments)\n0.00\n Accounts Receivables - Trade\n0.00\n A/R Tenants\n396,734.44\n A/R - Allowance for Doubtful\n0.00\nA/R Other\n0.00\n Title Escrow/Lender App\n0.00\n A/R Reserve Escrow BNY Mellon [TAFT]\n0.00\n A/R Frayser Village\n0.00\nA/R	994	6559	0	0	f	f	\N	\N	\N	{"total_pages": 5, "avg_text_per_page": 1310.2, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:21.278221+00	\N
17	TCSH 2024 Balance Sheet.pdf	3764	a8203d57fe9d34fc1a13e7de88105e10	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.59	2025-11-04 03:42:34.639507+00	["High gibberish ratio: 17.23%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n-100.00\n0123-0000\n Cash - Operating II\n0.13\n0125-0000\n Cash - Operating IV-PNC\n182,097.24\n0305-0000\n A/R Tenants\n196,488.27\n0306-0000\nA/R Other\n621,000.00\n0499-9000\n Total Current Assets\n999,485.64\n0500-0000\n Property & Equipment\n0510-0000\n Land\n5,145,300.00\n0610-0000\n Buildings\n24,092,306.22\n0710-0000\n 5 Year Improvements\n1,112,642.00\n0810-0000\n 15 Year Improvements\n5,956,169.06\n0815-0000\n 30 Year - Roof\n11,	325	2649	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1323.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:34.639507+00	\N
24	Wendover Commons 2024 Balance Sheet.pdf	3595	a1bb225e32356b98133686ab6b84a2d5	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.23	2025-11-04 03:42:51.742974+00	["High gibberish ratio: 17.41%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n-3,600.00\n0123-0000\n Cash - Operating II\n39,651.58\n0125-0000\n Cash - Operating IV-PNC\n211,729.81\n0305-0000\n A/R Tenants\n21,013.51\n0306-0000\nA/R Other\n389,132.00\n0499-9000\n Total Current Assets\n657,926.90\n0500-0000\n Property & Equipment\n0510-0000\n Land\n4,024,000.00\n0610-0000\n Buildings\n25,326,000.00\n0810-0000\n 15 Year Improvements\n5,960.00\n0815-0000\n 30 Year - Roof\n1,918.22\n0912-0000\n PARKING-LOT\n250.00\n0950-0	293	2425	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1211.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:51.742974+00	\N
30	ESP 2023 Balance Sheet.pdf	3585	a4050400f386bd451cf1a8fd901f9f67	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.36	2025-11-04 03:43:00.323705+00	["High gibberish ratio: 17.57%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n114,890.87\n0123-0000\n Cash - Operating II\n6,504.46\n0210-0000\n Accounts Receivables - Trade\n-56,028.54\n0305-0000\n A/R Tenants\n216,612.99\n0306-0000\nA/R Other\n200,000.00\n0499-9000\n Total Current Assets\n481,979.78\n0500-0000\n Property & Equipment\n0510-0000\n Land\n3,100,438.76\n0610-0000\n Buildings\n21,912,631.00\n0710-0000\n 5 Year Improvements\n1,016,850.00\n0810-0000\n 15 Year Improvements\n3,222,949.65\n0815-0000\n 30 Yea	296	2428	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1213.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:43:00.323705+00	\N
15	TCSH 2023 Income Statement.pdf	8207	ff8d69acf870d7cf03c5ac36c801c6d3	digital	3	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.45	2025-11-04 03:42:28.379615+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n4000-0000\n INCOME\n4010-0000\n Base Rentals\n311,945.05\n85.95\n3,712,352.25\n78.62\n4018-0000\nInterest Income\n0.00\n0.00\n154.79\n0.00\n4020-0000\n Tax\n13,223.02\n3.64\n151,336.24\n3.20\n4030-0000\n Insurance\n2,375.22\n0.65\n27,170.96\n0.58\n4040-0000\n CAM\n32,189.57\n8.87\n386,020.84\n8.18\n4055-0000\n Utilities Reimbursement\n314.27\n0.09\n314.27\n0.01\n4060-0000\n Annual Cams\n0.00\n0.00\n434,425.60\n9.20\n4090-0000\n Other Income\n2,637.23\n0.73\n7,539.23\n0.16\n4091-0000\nEnd of Day Investment Sweep 	692	4925	0	0	f	f	\N	\N	\N	{"total_pages": 3, "avg_text_per_page": 1640.33, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:28.379615+00	\N
16	TCSH 2023 Cash FLow Statement.pdf	25203	5b311264b8520d71e788d7ec09a8c511	digital	9	auto	["pymupdf"]	pymupdf	100	excellent	10	10	1.91	2025-11-04 03:42:30.62161+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n UN-Used - FUTURE Use\n0.00\n0.00\n0.00\n0.00\n INCOME\n Base Rentals\n3,712,352.25\n78.62\n3,712,352.25\n78.62\n Holdover Rent\n0.00\n0.00\n0.00\n0.00\n Free Rent\n0.00\n0.00\n0.00\n0.00\n Co-Tenancy Rent Reduction\n0.00\n0.00\n0.00\n0.00\n Bad Debt Expense\n0.00\n0.00\n0.00\n0.00\nManagement Fee Income\n0.00\n0.00\n0.00\n0.00\nAdmin Fee Income\n0.00\n0.00\n0.00\n0.00\nLeasing Commission Income\n0.00\n0.00\n0.00\n0.00\nConstruction Mgt Fee Income\n0.00\n0.00\n0.00\n0.00\nAccounting Fee Income\n0.00\n0.00\n0.00\n0.0	3018	18407	0	0	f	f	\N	\N	\N	{"total_pages": 9, "avg_text_per_page": 2194.4, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:30.62161+00	\N
19	TCSH 2024 Cash Flow Statement.pdf	25388	95b42632da1f0ddedd86eab7ae8d5c11	digital	9	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.66	2025-11-04 03:42:36.756675+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n UN-Used - FUTURE Use\n0.00\n0.00\n0.00\n0.00\n INCOME\n Base Rentals\n3,828,576.02\n86.71\n3,828,576.02\n86.71\n Holdover Rent\n0.00\n0.00\n0.00\n0.00\n Free Rent\n0.00\n0.00\n0.00\n0.00\n Co-Tenancy Rent Reduction\n0.00\n0.00\n0.00\n0.00\n Bad Debt Expense\n0.00\n0.00\n0.00\n0.00\nManagement Fee Income\n0.00\n0.00\n0.00\n0.00\nAdmin Fee Income\n0.00\n0.00\n0.00\n0.00\nLeasing Commission Income\n0.00\n0.00\n0.00\n0.00\nConstruction Mgt Fee Income\n0.00\n0.00\n0.00\n0.00\nAccounting Fee Income\n0.00\n0.00\n0.00\n0.0	3046	18633	0	0	f	f	\N	\N	\N	{"total_pages": 9, "avg_text_per_page": 2207.6, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:36.756675+00	\N
21	Wendover Commons 2023 Balance Sheet.pdf	3359	f90c162b4fc7683861d96a526c8db467	digital	6	auto	["pymupdf"]	pymupdf	100	excellent	10	10	2.1	2025-11-04 03:42:42.338306+00	[]	[]	["Extraction quality is high - safe to use"]	\N	Property\nUnit(s)\nLease\nLease Type\nArea\nLease From\nLease To\nTerm\nTenancy\nYears\nMonthly Rent\nMonthly\nRent/Area\nAnnual\nRent\nAnnual\nRent/Area\nAnnual\nRec./Area\nAnnual\nMisc/Area\nSecurity\nDeposit\nReceived\nLOC\nAmount/\nBank\nGuarantee\nThe Crossings of Spring\nHill (tcsh)\nTarget #-2362\n[NAP] (t0000351)\n[NAP]-Exp Only\n0.00\n02/23/2007\n12/31/2076\n839\n18.25\n0.00\n0.00\n0.00\n0.00\n0.00\n0.00\n0.00\n0.00\nGross Rent\n6,049.02\n0.00\n72,588.24\n0.00\nThe Crossings of Spring\nHill (tcsh)\n1000\nISP\nCorporation/Fireh\nouse Subs\n(t0	1743	11693	0	0	f	f	\N	\N	\N	{"total_pages": 6, "avg_text_per_page": 2171.2, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 1, "has_text_layer": true}	2025-11-04 03:42:42.338306+00	\N
29	Hammond Aire 2024 Cash Flow Statement.pdf	25785	26070f40babf1dd322391c3ccaa20562	digital	9	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.88	2025-11-04 03:42:59.230825+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n UN-Used - FUTURE Use\n0.00\n0.00\n0.00\n0.00\n INCOME\n Base Rentals\n3,518,849.59\n77.90\n3,518,849.59\n77.90\n Holdover Rent\n0.00\n0.00\n0.00\n0.00\n Free Rent\n0.00\n0.00\n0.00\n0.00\n Co-Tenancy Rent Reduction\n0.00\n0.00\n0.00\n0.00\n Bad Debt Expense\n0.00\n0.00\n0.00\n0.00\nManagement Fee Income\n6,297.17\n0.14\n6,297.17\n0.14\nAdmin Fee Income\n0.00\n0.00\n0.00\n0.00\nLeasing Commission Income\n0.00\n0.00\n0.00\n0.00\nConstruction Mgt Fee Income\n0.00\n0.00\n0.00\n0.00\nAccounting Fee Income\n0.00\n0.00\n	3040	18867	0	0	f	f	\N	\N	\N	{"total_pages": 9, "avg_text_per_page": 2208.4, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:59.230825+00	\N
34	ESP 2023 Balance Sheet.pdf	3585	a4050400f386bd451cf1a8fd901f9f67	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.86	2025-11-04 03:45:21.521475+00	["High gibberish ratio: 17.57%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n114,890.87\n0123-0000\n Cash - Operating II\n6,504.46\n0210-0000\n Accounts Receivables - Trade\n-56,028.54\n0305-0000\n A/R Tenants\n216,612.99\n0306-0000\nA/R Other\n200,000.00\n0499-9000\n Total Current Assets\n481,979.78\n0500-0000\n Property & Equipment\n0510-0000\n Land\n3,100,438.76\n0610-0000\n Buildings\n21,912,631.00\n0710-0000\n 5 Year Improvements\n1,016,850.00\n0810-0000\n 15 Year Improvements\n3,222,949.65\n0815-0000\n 30 Yea	296	2428	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1213.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:45:21.521475+00	\N
23	Wendover Commons 2023 Cash Flow Statement.pdf	25018	4c16a81f10f4a901f816315eedc41161	digital	9	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.43	2025-11-04 03:42:47.614602+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n UN-Used - FUTURE Use\n0.00\n0.00\n0.00\n0.00\n INCOME\n Base Rentals\n2,547,874.51\n78.85\n2,547,874.51\n78.85\n Holdover Rent\n0.00\n0.00\n0.00\n0.00\n Free Rent\n0.00\n0.00\n0.00\n0.00\n Co-Tenancy Rent Reduction\n0.00\n0.00\n0.00\n0.00\n Bad Debt Expense\n0.00\n0.00\n0.00\n0.00\nManagement Fee Income\n32.10\n0.00\n32.10\n0.00\nAdmin Fee Income\n0.00\n0.00\n0.00\n0.00\nLeasing Commission Income\n0.00\n0.00\n0.00\n0.00\nConstruction Mgt Fee Income\n0.00\n0.00\n0.00\n0.00\nAccounting Fee Income\n0.00\n0.00\n0.00\n0	3003	18249	0	0	f	f	\N	\N	\N	{"total_pages": 9, "avg_text_per_page": 2172.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:47.614602+00	\N
25	Wendover Commons 2024 Income Statement.pdf	7531	6268cba12fab48ad7d9112158be62688	digital	3	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.38	2025-11-04 03:42:51.942071+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n4000-0000\n INCOME\n4010-0000\n Base Rentals\n2,588,055.53\n81.40\n2,588,055.53\n81.40\n4013-0000\nManagement Fee Income\n9.00\n0.00\n9.00\n0.00\n4020-0000\n Tax\n152,404.65\n4.79\n152,404.65\n4.79\n4030-0000\n Insurance\n16,998.20\n0.53\n16,998.20\n0.53\n4040-0000\n CAM\n186,200.36\n5.86\n186,200.36\n5.86\n4060-0000\n Annual Cams\n199,389.15\n6.27\n199,389.15\n6.27\n4090-0000\n Other Income\n36,400.00\n1.14\n36,400.00\n1.14\n4990-0000\n TOTAL INCOME\n3,179,456.89\n100.00\n3,179,456.89\n100.00\n5000-0000\n EXPEN	624	4635	0	0	f	f	\N	\N	\N	{"total_pages": 3, "avg_text_per_page": 1543.67, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:51.942071+00	\N
27	Wendover Rent Roll April 2025.pdf	29636	5e264c38b7c52ef67eeac3658f0d69e6	digital	3	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.95	2025-11-04 03:42:53.448365+00	[]	[]	["Extraction quality is high - safe to use"]	\N	Property\nUnit(s)\nLease\nLease Type\nArea\nLease From\nLease To\nTerm\nTenancy\nYears\nMonthly Rent\nMonthly\nRent/Area\nAnnual\nRent\nAnnual\nRent/Area\nAnnual\nRec./Area\nAnnual\nMisc/Area\nSecurity\nDeposit\nReceived\nLOC\nAmount/\nBank\nGuarantee\nWendover Commons\n(wend)\nB-101\nFirst Watch\nRestuarants Inc\n(t0000494)\nRetail NNN\n3,327.00\n01/13/2020\n01/31/2030\n121\n5.33\n10,674.13\n3.21 128,089.56\n38.50\n5.74\n0.00\n0.00\n0.00\nGross Rent\n12,264.25\n3.69 147,171.00\n44.24\nWendover Commons\n(wend)\nB-107\nGreensboro\nSports Nutrition,\nL	736	5037	0	0	f	f	\N	\N	\N	{"total_pages": 3, "avg_text_per_page": 1677.67, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 1, "has_text_layer": true}	2025-11-04 03:42:53.448365+00	\N
32	ESP 2024 Balance Sheet.pdf	8358	15a5bbadb72da091f20e00d6ec3cf1ec	digital	5	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.75	2025-11-04 03:45:17.418505+00	[]	[]	["Extraction quality is high - safe to use"]	\N	Current Balance\n ASSETS\n Current Assets\n Cash on Hand\n0.00\n Cash - Savings\n0.00\n Cash - Operating\n-1,080.00\n Cash - Operating II\n6,504.46\n Cash - Operating III WF\n0.00\n Cash - Operating IV-PNC\n365,638.38\n Cash - Depository - PNC\n0.00\n Cash - Escrow - PNC\n0.00\n Non-Cash (Adjustments)\n0.00\n Accounts Receivables - Trade\n-59,213.38\n A/R Tenants\n210,365.06\n A/R - Allowance for Doubtful\n0.00\nA/R Other\n0.00\n Title Escrow/Lender App\n0.00\n A/R Reserve Escrow BNY Mellon [TAFT]\n0.00\n A/R Frayser Village\n0.	994	6509	0	0	f	f	\N	\N	\N	{"total_pages": 5, "avg_text_per_page": 1300.2, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:45:17.418505+00	\N
35	TCSH 2023 Balance Sheet.pdf	3686	4decd7e9779c9969fe5631c083dea106	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	1.27	2025-11-04 03:45:25.559079+00	["High gibberish ratio: 17.49%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n566,871.52\n0305-0000\n A/R Tenants\n362,040.37\n0306-0000\nA/R Other\n7,252.23\n0499-9000\n Total Current Assets\n936,164.12\n0500-0000\n Property & Equipment\n0510-0000\n Land\n5,145,300.00\n0610-0000\n Buildings\n24,092,306.22\n0710-0000\n 5 Year Improvements\n1,112,642.00\n0810-0000\n 15 Year Improvements\n5,956,169.06\n0815-0000\n 30 Year - Roof\n11,972.09\n0910-0000\n Other Improvements\n542,500.00\n0912-0000\n PARKING-LOT\n8,619.54\n1	303	2495	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1246.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:45:25.559079+00	\N
26	Wendover Commons 2024 Cash Flow Statement.pdf	25263	f8ce93aca4295d1c052db5354ca1869e	digital	9	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.54	2025-11-04 03:42:53.12717+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n UN-Used - FUTURE Use\n0.00\n0.00\n0.00\n0.00\n INCOME\n Base Rentals\n2,588,055.53\n81.40\n2,588,055.53\n81.40\n Holdover Rent\n0.00\n0.00\n0.00\n0.00\n Free Rent\n0.00\n0.00\n0.00\n0.00\n Co-Tenancy Rent Reduction\n0.00\n0.00\n0.00\n0.00\n Bad Debt Expense\n0.00\n0.00\n0.00\n0.00\nManagement Fee Income\n9.00\n0.00\n9.00\n0.00\nAdmin Fee Income\n0.00\n0.00\n0.00\n0.00\nLeasing Commission Income\n0.00\n0.00\n0.00\n0.00\nConstruction Mgt Fee Income\n0.00\n0.00\n0.00\n0.00\nAccounting Fee Income\n0.00\n0.00\n0.00\n0.0	3031	18515	0	0	f	f	\N	\N	\N	{"total_pages": 9, "avg_text_per_page": 2182.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:53.12717+00	\N
28	Hammond Aire 2024 Income Statement.pdf	14164	270e29c788951852b4d1efd93b533ab5	digital	5	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.52	2025-11-04 03:42:56.215162+00	[]	[]	["Extraction quality is high - safe to use"]	\N	 Period to Date\n%\n Year to Date\n%\n UN-Used - FUTURE Use\n0.00\n0.00\n0.00\n0.00\n INCOME\n Base Rentals\n3,518,849.59\n77.90\n3,518,849.59\n77.90\n Holdover Rent\n0.00\n0.00\n0.00\n0.00\n Free Rent\n0.00\n0.00\n0.00\n0.00\n Co-Tenancy Rent Reduction\n0.00\n0.00\n0.00\n0.00\n Bad Debt Expense\n0.00\n0.00\n0.00\n0.00\nManagement Fee Income\n6,297.17\n0.14\n6,297.17\n0.14\nAdmin Fee Income\n0.00\n0.00\n0.00\n0.00\nLeasing Commission Income\n0.00\n0.00\n0.00\n0.00\nConstruction Mgt Fee Income\n0.00\n0.00\n0.00\n0.00\nAccounting Fee Income\n0.00\n0.00\n	1565	9987	0	0	f	f	\N	\N	\N	{"total_pages": 5, "avg_text_per_page": 1995.8, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:42:56.215162+00	\N
31	Hammond Aire 2023 Balance Sheet.pdf	3568	d2a57acc42ae11e3d827351c5a8235d1	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.64	2025-11-04 03:45:17.385881+00	["High gibberish ratio: 17.24%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n129,504.76\n0123-0000\n Cash - Operating II\n5,000.00\n0305-0000\n A/R Tenants\n288,583.04\n0347-0000\n Escrow - Other\n281,295.46\n0499-9000\n Total Current Assets\n704,383.26\n0500-0000\n Property & Equipment\n0510-0000\n Land\n6,000,000.00\n0610-0000\n Buildings\n24,746,662.00\n0710-0000\n 5 Year Improvements\n2,404,328.00\n0810-0000\n 15 Year Improvements\n7,050,280.00\n1061-0000\n Accum. Depr. - Buildings\n-2,485,241.70\n1071-0000\n A	290	2395	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1196.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:45:17.385881+00	\N
33	Hammond Aire2024 Balance Sheet.pdf	8387	ad68ed4a7127d403a01c493bfa3287b3	digital	5	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.79	2025-11-04 03:45:20.413828+00	[]	[]	["Extraction quality is high - safe to use"]	\N	Current Balance\n ASSETS\n Current Assets\n Cash on Hand\n0.00\n Cash - Savings\n0.00\n Cash - Operating\n-3,549.10\n Cash - Operating II\n5,000.00\n Cash - Operating III WF\n0.00\n Cash - Operating IV-PNC\n234,349.36\n Cash - Depository - PNC\n0.00\n Cash - Escrow - PNC\n0.00\n Non-Cash (Adjustments)\n0.00\n Accounts Receivables - Trade\n0.00\n A/R Tenants\n396,734.44\n A/R - Allowance for Doubtful\n0.00\nA/R Other\n0.00\n Title Escrow/Lender App\n0.00\n A/R Reserve Escrow BNY Mellon [TAFT]\n0.00\n A/R Frayser Village\n0.00\nA/R	994	6559	0	0	f	f	\N	\N	\N	{"total_pages": 5, "avg_text_per_page": 1310.2, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:45:20.413828+00	\N
36	TCSH 2024 Balance Sheet.pdf	3764	a8203d57fe9d34fc1a13e7de88105e10	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.61	2025-11-04 03:45:26.435898+00	["High gibberish ratio: 17.23%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n-100.00\n0123-0000\n Cash - Operating II\n0.13\n0125-0000\n Cash - Operating IV-PNC\n182,097.24\n0305-0000\n A/R Tenants\n196,488.27\n0306-0000\nA/R Other\n621,000.00\n0499-9000\n Total Current Assets\n999,485.64\n0500-0000\n Property & Equipment\n0510-0000\n Land\n5,145,300.00\n0610-0000\n Buildings\n24,092,306.22\n0710-0000\n 5 Year Improvements\n1,112,642.00\n0810-0000\n 15 Year Improvements\n5,956,169.06\n0815-0000\n 30 Year - Roof\n11,	325	2649	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1323.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:45:26.435898+00	\N
37	Wendover Commons 2023 Balance Sheet.pdf	3359	f90c162b4fc7683861d96a526c8db467	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	1.62	2025-11-04 03:45:28.117357+00	["High gibberish ratio: 17.72%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n246,111.90\n0305-0000\n A/R Tenants\n20,137.51\n0306-0000\nA/R Other\n140,132.00\n0499-9000\n Total Current Assets\n406,381.41\n0500-0000\n Property & Equipment\n0510-0000\n Land\n4,024,000.00\n0610-0000\n Buildings\n25,326,000.00\n0810-0000\n 15 Year Improvements\n5,960.00\n0815-0000\n 30 Year - Roof\n1,918.22\n0912-0000\n PARKING-LOT\n250.00\n1061-0000\n Accum. Depr. - Buildings\n-1,784,008.00\n1071-0000\n Accum. Depr. 5 Year Impr.\n-2,49	254	2106	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1052.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:45:28.117357+00	\N
38	Wendover Commons 2024 Balance Sheet.pdf	3595	a1bb225e32356b98133686ab6b84a2d5	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	1.2	2025-11-04 03:45:29.166297+00	["High gibberish ratio: 17.41%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n-3,600.00\n0123-0000\n Cash - Operating II\n39,651.58\n0125-0000\n Cash - Operating IV-PNC\n211,729.81\n0305-0000\n A/R Tenants\n21,013.51\n0306-0000\nA/R Other\n389,132.00\n0499-9000\n Total Current Assets\n657,926.90\n0500-0000\n Property & Equipment\n0510-0000\n Land\n4,024,000.00\n0610-0000\n Buildings\n25,326,000.00\n0810-0000\n 15 Year Improvements\n5,960.00\n0815-0000\n 30 Year - Roof\n1,918.22\n0912-0000\n PARKING-LOT\n250.00\n0950-0	293	2425	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1211.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:45:29.166297+00	\N
39	ESP 2024 Balance Sheet.pdf	8358	15a5bbadb72da091f20e00d6ec3cf1ec	digital	5	auto	["pymupdf"]	pymupdf	100	excellent	10	10	2.46	2025-11-04 03:50:33.976846+00	[]	[]	["Extraction quality is high - safe to use"]	\N	Current Balance\n ASSETS\n Current Assets\n Cash on Hand\n0.00\n Cash - Savings\n0.00\n Cash - Operating\n-1,080.00\n Cash - Operating II\n6,504.46\n Cash - Operating III WF\n0.00\n Cash - Operating IV-PNC\n365,638.38\n Cash - Depository - PNC\n0.00\n Cash - Escrow - PNC\n0.00\n Non-Cash (Adjustments)\n0.00\n Accounts Receivables - Trade\n-59,213.38\n A/R Tenants\n210,365.06\n A/R - Allowance for Doubtful\n0.00\nA/R Other\n0.00\n Title Escrow/Lender App\n0.00\n A/R Reserve Escrow BNY Mellon [TAFT]\n0.00\n A/R Frayser Village\n0.	994	6509	0	0	f	f	\N	\N	\N	{"total_pages": 5, "avg_text_per_page": 1300.2, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:50:33.976846+00	\N
40	Hammond Aire 2023 Balance Sheet.pdf	3568	d2a57acc42ae11e3d827351c5a8235d1	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	2.36	2025-11-04 03:50:34.062272+00	["High gibberish ratio: 17.24%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n129,504.76\n0123-0000\n Cash - Operating II\n5,000.00\n0305-0000\n A/R Tenants\n288,583.04\n0347-0000\n Escrow - Other\n281,295.46\n0499-9000\n Total Current Assets\n704,383.26\n0500-0000\n Property & Equipment\n0510-0000\n Land\n6,000,000.00\n0610-0000\n Buildings\n24,746,662.00\n0710-0000\n 5 Year Improvements\n2,404,328.00\n0810-0000\n 15 Year Improvements\n7,050,280.00\n1061-0000\n Accum. Depr. - Buildings\n-2,485,241.70\n1071-0000\n A	290	2395	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1196.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:50:34.062272+00	\N
41	Hammond Aire2024 Balance Sheet.pdf	8387	ad68ed4a7127d403a01c493bfa3287b3	digital	5	auto	["pymupdf"]	pymupdf	100	excellent	10	10	0.22	2025-11-04 03:50:37.994327+00	[]	[]	["Extraction quality is high - safe to use"]	\N	Current Balance\n ASSETS\n Current Assets\n Cash on Hand\n0.00\n Cash - Savings\n0.00\n Cash - Operating\n-3,549.10\n Cash - Operating II\n5,000.00\n Cash - Operating III WF\n0.00\n Cash - Operating IV-PNC\n234,349.36\n Cash - Depository - PNC\n0.00\n Cash - Escrow - PNC\n0.00\n Non-Cash (Adjustments)\n0.00\n Accounts Receivables - Trade\n0.00\n A/R Tenants\n396,734.44\n A/R - Allowance for Doubtful\n0.00\nA/R Other\n0.00\n Title Escrow/Lender App\n0.00\n A/R Reserve Escrow BNY Mellon [TAFT]\n0.00\n A/R Frayser Village\n0.00\nA/R	994	6559	0	0	f	f	\N	\N	\N	{"total_pages": 5, "avg_text_per_page": 1310.2, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:50:37.994327+00	\N
43	TCSH 2023 Balance Sheet.pdf	3686	4decd7e9779c9969fe5631c083dea106	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.48	2025-11-04 03:50:40.036639+00	["High gibberish ratio: 17.49%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n566,871.52\n0305-0000\n A/R Tenants\n362,040.37\n0306-0000\nA/R Other\n7,252.23\n0499-9000\n Total Current Assets\n936,164.12\n0500-0000\n Property & Equipment\n0510-0000\n Land\n5,145,300.00\n0610-0000\n Buildings\n24,092,306.22\n0710-0000\n 5 Year Improvements\n1,112,642.00\n0810-0000\n 15 Year Improvements\n5,956,169.06\n0815-0000\n 30 Year - Roof\n11,972.09\n0910-0000\n Other Improvements\n542,500.00\n0912-0000\n PARKING-LOT\n8,619.54\n1	303	2495	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1246.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:50:40.036639+00	\N
45	Wendover Commons 2023 Balance Sheet.pdf	3359	f90c162b4fc7683861d96a526c8db467	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.82	2025-11-04 03:50:41.55836+00	["High gibberish ratio: 17.72%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n246,111.90\n0305-0000\n A/R Tenants\n20,137.51\n0306-0000\nA/R Other\n140,132.00\n0499-9000\n Total Current Assets\n406,381.41\n0500-0000\n Property & Equipment\n0510-0000\n Land\n4,024,000.00\n0610-0000\n Buildings\n25,326,000.00\n0810-0000\n 15 Year Improvements\n5,960.00\n0815-0000\n 30 Year - Roof\n1,918.22\n0912-0000\n PARKING-LOT\n250.00\n1061-0000\n Accum. Depr. - Buildings\n-1,784,008.00\n1071-0000\n Accum. Depr. 5 Year Impr.\n-2,49	254	2106	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1052.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:50:41.55836+00	\N
42	ESP 2023 Balance Sheet.pdf	3585	a4050400f386bd451cf1a8fd901f9f67	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.41	2025-11-04 03:50:38.920063+00	["High gibberish ratio: 17.57%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n114,890.87\n0123-0000\n Cash - Operating II\n6,504.46\n0210-0000\n Accounts Receivables - Trade\n-56,028.54\n0305-0000\n A/R Tenants\n216,612.99\n0306-0000\nA/R Other\n200,000.00\n0499-9000\n Total Current Assets\n481,979.78\n0500-0000\n Property & Equipment\n0510-0000\n Land\n3,100,438.76\n0610-0000\n Buildings\n21,912,631.00\n0710-0000\n 5 Year Improvements\n1,016,850.00\n0810-0000\n 15 Year Improvements\n3,222,949.65\n0815-0000\n 30 Yea	296	2428	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1213.0, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:50:38.920063+00	\N
44	TCSH 2024 Balance Sheet.pdf	3764	a8203d57fe9d34fc1a13e7de88105e10	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	0.23	2025-11-04 03:50:40.947402+00	["High gibberish ratio: 17.23%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n-100.00\n0123-0000\n Cash - Operating II\n0.13\n0125-0000\n Cash - Operating IV-PNC\n182,097.24\n0305-0000\n A/R Tenants\n196,488.27\n0306-0000\nA/R Other\n621,000.00\n0499-9000\n Total Current Assets\n999,485.64\n0500-0000\n Property & Equipment\n0510-0000\n Land\n5,145,300.00\n0610-0000\n Buildings\n24,092,306.22\n0710-0000\n 5 Year Improvements\n1,112,642.00\n0810-0000\n 15 Year Improvements\n5,956,169.06\n0815-0000\n 30 Year - Roof\n11,	325	2649	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1323.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:50:40.947402+00	\N
46	Wendover Commons 2024 Balance Sheet.pdf	3595	a1bb225e32356b98133686ab6b84a2d5	digital	2	auto	["pymupdf"]	pymupdf	84	acceptable	9	10	1.05	2025-11-04 03:50:43.716823+00	["High gibberish ratio: 17.41%"]	[]	["Spot check extraction results", "Consider using multiple engines for validation", "Document may be scanned - use OCR engine", "Check image quality and orientation"]	\N	Current Balance\n0100-0000\n ASSETS\n0101-0000\n Current Assets\n0122-0000\n Cash - Operating\n-3,600.00\n0123-0000\n Cash - Operating II\n39,651.58\n0125-0000\n Cash - Operating IV-PNC\n211,729.81\n0305-0000\n A/R Tenants\n21,013.51\n0306-0000\nA/R Other\n389,132.00\n0499-9000\n Total Current Assets\n657,926.90\n0500-0000\n Property & Equipment\n0510-0000\n Land\n4,024,000.00\n0610-0000\n Buildings\n25,326,000.00\n0810-0000\n 15 Year Improvements\n5,960.00\n0815-0000\n 30 Year - Roof\n1,918.22\n0912-0000\n PARKING-LOT\n250.00\n0950-0	293	2425	0	0	t	f	\N	\N	\N	{"total_pages": 2, "avg_text_per_page": 1211.5, "avg_images_per_page": 0.0, "text_coverage": 100.0, "table_count": 0, "has_text_layer": true}	2025-11-04 03:50:43.716823+00	\N
\.


--
-- Data for Name: extraction_templates; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.extraction_templates (id, template_name, document_type, template_structure, keywords, extraction_rules, is_default, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: financial_metrics; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.financial_metrics (id, property_id, period_id, total_assets, total_liabilities, total_equity, current_ratio, debt_to_equity_ratio, total_revenue, total_expenses, net_operating_income, net_income, operating_margin, profit_margin, operating_cash_flow, investing_cash_flow, financing_cash_flow, net_cash_flow, beginning_cash_balance, ending_cash_balance, total_units, occupied_units, vacant_units, occupancy_rate, total_leasable_sqft, occupied_sqft, total_monthly_rent, total_annual_rent, avg_rent_per_sqft, noi_per_sqft, revenue_per_sqft, expense_ratio, calculated_at, created_at, updated_at) FROM stdin;
1	2	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	14.00	\N	\N	14.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-04 03:42:05.676925+00	2025-11-04 03:42:05.676925+00	2025-11-04 03:42:11.490607+00
2	2	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	14.00	\N	\N	14.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-04 03:42:16.362284+00	2025-11-04 03:42:16.362284+00	\N
4	2	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	27	27	0	100.00	\N	\N	903822.08	10845864.96	\N	\N	\N	\N	2025-11-04 03:42:21.034529+00	2025-11-04 03:42:21.034529+00	\N
3	3	4	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	14.00	\N	\N	14.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-04 03:42:19.5058+00	2025-11-04 03:42:19.5058+00	2025-11-04 03:42:25.715489+00
6	3	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	41	41	0	100.00	\N	\N	689737.00	8276844.00	\N	\N	\N	\N	2025-11-04 03:42:34.353566+00	2025-11-04 03:42:34.353566+00	\N
5	4	7	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	14.00	\N	\N	14.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-04 03:42:29.985525+00	2025-11-04 03:42:29.985525+00	2025-11-04 03:42:36.609127+00
7	4	8	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	14.00	\N	\N	14.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-04 03:42:40.473373+00	2025-11-04 03:42:40.473373+00	2025-11-04 03:42:41.466266+00
9	4	9	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	39	39	0	100.00	\N	\N	439828.25	5277939.00	\N	\N	\N	\N	2025-11-04 03:42:51.526364+00	2025-11-04 03:42:51.526364+00	\N
8	5	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	14.00	\N	\N	14.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-04 03:42:47.301169+00	2025-11-04 03:42:47.301169+00	2025-11-04 03:42:51.709338+00
10	5	11	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	14.00	\N	\N	14.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-04 03:42:53.254963+00	2025-11-04 03:42:53.254963+00	2025-11-04 03:42:56.063832+00
11	5	12	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	17	17	0	100.00	\N	\N	302152.00	3625824.00	\N	\N	\N	\N	2025-11-04 03:42:58.474361+00	2025-11-04 03:42:58.474361+00	\N
\.


--
-- Data for Name: financial_periods; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.financial_periods (id, property_id, period_year, period_month, period_start_date, period_end_date, fiscal_year, fiscal_quarter, is_closed, closed_date, closed_by, created_at) FROM stdin;
1	2	2023	12	2023-12-01	2023-12-31	2023	4	f	\N	\N	2025-11-04 03:12:59.698466+00
2	2	2024	12	2024-12-01	2024-12-31	2024	4	f	\N	\N	2025-11-04 03:19:06.420654+00
3	2	2025	4	2025-04-01	2025-04-30	2025	2	f	\N	\N	2025-11-04 03:22:52.07227+00
4	3	2023	12	2023-12-01	2023-12-31	2023	4	f	\N	\N	2025-11-04 03:22:52.297+00
5	3	2024	12	2024-12-01	2024-12-31	2024	4	f	\N	\N	2025-11-04 03:22:53.005174+00
6	3	2025	4	2025-04-01	2025-04-30	2025	2	f	\N	\N	2025-11-04 03:22:53.351095+00
7	4	2023	12	2023-12-01	2023-12-31	2023	4	f	\N	\N	2025-11-04 03:22:53.725543+00
8	4	2024	12	2024-12-01	2024-12-31	2024	4	f	\N	\N	2025-11-04 03:22:54.472107+00
9	4	2025	4	2025-04-01	2025-04-30	2025	2	f	\N	\N	2025-11-04 03:22:55.259866+00
10	5	2023	12	2023-12-01	2023-12-31	2023	4	f	\N	\N	2025-11-04 03:22:55.567455+00
11	5	2024	12	2024-12-01	2024-12-31	2024	4	f	\N	\N	2025-11-04 03:22:56.357427+00
12	5	2025	4	2025-04-01	2025-04-30	2025	2	f	\N	\N	2025-11-04 03:22:57.130639+00
\.


--
-- Data for Name: income_statement_data; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.income_statement_data (id, property_id, period_id, upload_id, account_id, account_code, account_name, period_amount, ytd_amount, period_percentage, ytd_percentage, is_income, is_calculated, parent_account_code, extraction_confidence, needs_review, reviewed, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
1	2	2	6	86	-2016	Parking Lot	7.00	\N	\N	\N	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:12.433417+00	\N
2	2	2	6	86	-2017	Parking Lot	7.00	\N	\N	\N	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:12.433417+00	\N
3	3	5	27	86	-2016	Parking Lot	7.00	\N	\N	\N	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:56.768745+00	\N
4	3	5	27	86	-2017	Parking Lot	7.00	\N	\N	\N	\N	f	\N	100.00	f	f	\N	\N	\N	2025-11-04 03:42:56.768745+00	\N
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.properties (id, property_code, property_name, property_type, address, city, state, zip_code, country, total_area_sqft, acquisition_date, ownership_structure, status, notes, created_at, updated_at, created_by) FROM stdin;
1	TEST001	Test Property	multifamily	123 Test St	Test City	TS	12345	USA	\N	\N	\N	active	\N	2025-11-04 02:31:20.654241+00	\N	1
2	ESP001	Esplanade Shopping Center	retail	1234 Main Street	Phoenix	AZ	85001	USA	125000.50	2020-01-15	LLC	active	Premium shopping center in Phoenix metro area	2025-11-04 03:12:43.586502+00	\N	\N
3	HMND001	Hammond Aire Shopping Center	retail	5678 Commerce Drive	Hammond	IN	46320	USA	98500.00	2019-06-01	Partnership	active	Regional shopping center in Hammond, Indiana	2025-11-04 03:12:43.586502+00	\N	\N
4	TCSH001	Town Center Shopping	retail	9012 Center Boulevard	Town Center	FL	33411	USA	110250.00	2021-03-20	LLC	active	Mixed-use retail center in South Florida	2025-11-04 03:12:43.586502+00	\N	\N
5	WEND001	Wendover Commons	retail	3456 Wendover Avenue	Greensboro	NC	27407	USA	87600.00	2018-11-10	LLC	active	Community shopping center in Greensboro, NC	2025-11-04 03:12:43.586502+00	\N	\N
\.


--
-- Data for Name: rent_roll_data; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.rent_roll_data (id, property_id, period_id, upload_id, unit_number, tenant_name, tenant_code, lease_type, lease_start_date, lease_end_date, lease_term_months, remaining_lease_years, unit_area_sqft, monthly_rent, monthly_rent_per_sqft, annual_rent, annual_rent_per_sqft, gross_rent, security_deposit, loc_amount, annual_cam_reimbursement, annual_tax_reimbursement, annual_insurance_reimbursement, occupancy_status, lease_status, extraction_confidence, needs_review, reviewed, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
1	2	3	7	249	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	20.08	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
2	2	3	7	106	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	1800.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
3	2	3	7	108	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	1600.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
4	2	3	7	110	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	20087.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
5	2	3	7	120	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	21360.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
6	2	3	7	130	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	30981.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
7	2	3	7	140	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	30187.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
8	2	3	7	150	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	18982.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
9	2	3	7	160	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	18230.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
10	2	3	7	170	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	3500.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
11	2	3	7	180	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	10000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
12	2	3	7	200	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	5000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
13	2	3	7	210	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	45000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
14	2	3	7	300	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	4468.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
15	2	3	7	85	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	400402.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
16	2	3	7	406	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	2100.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
17	2	3	7	500	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	3200.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
18	2	3	7	504	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	1600.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
19	2	3	7	506	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	1600.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
20	2	3	7	508	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	1600.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
21	2	3	7	A-10136	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	6000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
22	2	3	7	B-10136	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	6000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
23	2	3	7	100	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	4500.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
24	2	3	7	175	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	4000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
25	2	3	7	600	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	9660.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
26	2	3	7	608	Eastern Shore Plaza\n(esp)	\N	\N	\N	\N	\N	\N	\N	12750.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
27	2	3	7	21	Retail NNN	\N	\N	\N	\N	\N	\N	\N	239195.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:17.67036+00	\N
28	3	6	12	001	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	703.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
29	3	6	12	002-A	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1312.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
30	3	6	12	002-B	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1590.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
31	3	6	12	003	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1410.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
32	3	6	12	004	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1023.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
33	3	6	12	005	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	4200.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
34	3	6	12	006	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	10494.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
35	3	6	12	008-B	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	4452.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
36	3	6	12	008-C	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	3094.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
37	3	6	12	68	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	10135.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
38	3	6	12	010	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1380.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
39	3	6	12	012	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	3023.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
40	3	6	12	014	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1320.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
41	3	6	12	60	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	15016.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
42	3	6	12	017	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1910.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
43	3	6	12	018	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1740.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
44	3	6	12	019	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1157.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
45	3	6	12	021	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1745.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
46	3	6	12	025	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	23400.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
47	3	6	12	028	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	40000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
48	3	6	12	030	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	15920.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
49	3	6	12	036	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	6449.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
50	3	6	12	044	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	2125.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
51	3	6	12	046	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1845.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
52	3	6	12	048	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	32723.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
53	3	6	12	050-B	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	12500.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
54	3	6	12	057	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	13837.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
55	3	6	12	060	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	25000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
56	3	6	12	062	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	6600.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
57	3	6	12	099	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	80450.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
58	3	6	12	0D0	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	3910.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
59	3	6	12	0G0	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	9433.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
60	3	6	12	LAND	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	181.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
61	3	6	12	020	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	1149.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
62	3	6	12	042	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	6087.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
63	3	6	12	055	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	5853.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
64	3	6	12	064	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	810.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
65	3	6	12	0B0	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	3449.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
66	3	6	12	0C0	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	2550.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
67	3	6	12	0F0	Hammond Aire Plaza\n(hmnd)	\N	\N	\N	\N	\N	\N	\N	3067.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
68	3	6	12	33	Retail NNN	\N	\N	\N	\N	\N	\N	\N	326695.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:25.107656+00	\N
69	4	9	19	839	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	18.25	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
70	4	9	19	1000	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	2261.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
71	4	9	19	1001	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	2400.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
72	4	9	19	1002	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1790.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
73	4	9	19	1005	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1200.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
74	4	9	19	1006	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	4786.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
75	4	9	19	1007	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1200.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
76	4	9	19	1008	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1200.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
77	4	9	19	1009	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	4800.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
78	4	9	19	1010	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1600.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
79	4	9	19	1011	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1600.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
80	4	9	19	1012B	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1517.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
81	4	9	19	1012C	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1683.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
82	4	9	19	1013	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1600.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
83	4	9	19	1014	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	5000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
84	4	9	19	1015	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	2400.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
85	4	9	19	1016	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	5000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
86	4	9	19	1017	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1600.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
87	4	9	19	1018	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	6200.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
88	4	9	19	1019	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1600.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
89	4	9	19	1021	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	1600.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
90	4	9	19	1022	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	24911.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
91	4	9	19	1024	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	7500.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
92	4	9	19	1025	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	3800.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
93	4	9	19	1026	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	6500.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
94	4	9	19	1027	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	2000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
95	4	9	19	1028	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	8027.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
96	4	9	19	1029	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	2400.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
97	4	9	19	1030	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	23391.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
98	4	9	19	1036A	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	2500.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
99	4	9	19	128	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	4500.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
100	4	9	19	1037	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	5200.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
101	4	9	19	1038	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	18471.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
102	4	9	19	1040	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	15500.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
103	4	9	19	1041	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	20331.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
104	4	9	19	2000	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	6387.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
105	4	9	19	2008	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	7290.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
106	4	9	19	2020	The Crossings of Spring\nHill (tcsh)	\N	\N	\N	\N	\N	\N	\N	10160.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
107	4	9	19	37	Retail NNN	\N	\N	\N	\N	\N	\N	\N	219905.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	84.00	t	f	\N	\N	\N	2025-11-04 03:42:43.034744+00	\N
108	5	12	26	B-101	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	3327.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
109	5	12	26	B-107	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	1360.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
110	5	12	26	B-110	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	3553.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
111	5	12	26	C-101	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	3800.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
112	5	12	26	C-110	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	2360.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
113	5	12	26	D--10	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	2973.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
114	5	12	26	D--50	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	2340.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
115	5	12	26	D-100	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	1200.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
116	5	12	26	E-102	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	17868.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
117	5	12	26	F-103	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	64264.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
118	5	12	26	H-101	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	2800.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
119	5	12	26	H-110	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	3200.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
120	5	12	26	OP-01	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	6609.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
121	5	12	26	OP-02	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	35362.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
122	5	12	26	Z-ATM	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	120.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
123	5	12	26	COMMON	Wendover Commons\n(wend)	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
124	5	12	26	15	Retail NNN	\N	\N	\N	\N	\N	\N	\N	151016.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	occupied	active	100.00	f	f	\N	\N	\N	2025-11-04 03:42:54.443466+00	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.users (id, email, username, hashed_password, is_active, is_superuser, created_at, updated_at) FROM stdin;
1	system@reims.local	system	not_used	t	t	2025-11-03 23:06:21.107128+00	\N
\.


--
-- Data for Name: validation_results; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.validation_results (id, upload_id, rule_id, passed, expected_value, actual_value, difference, difference_percentage, error_message, severity, created_at) FROM stdin;
1	3	8	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:42:05.820839+00
2	3	11	t	0.00	0.00	\N	\N	\N	warning	2025-11-04 03:42:05.965833+00
3	3	10	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:42:05.999364+00
4	2	12	t	14.00	14.00	0.00	\N	\N	error	2025-11-04 03:42:11.606454+00
5	5	12	t	14.00	14.00	0.00	\N	\N	error	2025-11-04 03:42:16.455099+00
6	6	8	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:42:16.520491+00
7	6	11	t	0.00	0.00	\N	\N	\N	warning	2025-11-04 03:42:16.574833+00
8	6	10	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:42:16.593553+00
9	9	8	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:42:19.571088+00
10	9	11	t	0.00	0.00	\N	\N	\N	warning	2025-11-04 03:42:19.617402+00
11	9	10	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:42:19.650974+00
12	7	17	t	0.00	0.00	\N	\N	\N	error	2025-11-04 03:42:21.074124+00
13	7	18	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:42:21.099156+00
14	10	12	t	14.00	14.00	0.00	\N	\N	error	2025-11-04 03:42:25.779307+00
15	14	8	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:42:30.246715+00
16	14	11	t	0.00	0.00	\N	\N	\N	warning	2025-11-04 03:42:30.334868+00
17	14	10	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:42:30.381295+00
18	12	17	t	0.00	0.00	\N	\N	\N	error	2025-11-04 03:42:34.438704+00
19	12	18	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:42:34.485825+00
20	15	12	t	14.00	14.00	0.00	\N	\N	error	2025-11-04 03:42:36.632131+00
21	17	8	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:42:40.541366+00
22	17	11	t	0.00	0.00	\N	\N	\N	warning	2025-11-04 03:42:40.589905+00
23	17	10	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:42:40.630334+00
24	18	12	t	14.00	14.00	0.00	\N	\N	error	2025-11-04 03:42:41.730112+00
25	21	8	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:42:47.341169+00
26	21	11	t	0.00	0.00	\N	\N	\N	warning	2025-11-04 03:42:47.383917+00
27	21	10	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:42:47.405638+00
28	19	17	t	0.00	0.00	\N	\N	\N	error	2025-11-04 03:42:51.553622+00
29	19	18	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:42:51.578328+00
30	22	12	t	14.00	14.00	0.00	\N	\N	error	2025-11-04 03:42:51.753008+00
31	24	8	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:42:53.283021+00
32	24	11	t	0.00	0.00	\N	\N	\N	warning	2025-11-04 03:42:53.303112+00
33	24	10	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:42:53.326491+00
34	25	12	t	14.00	14.00	0.00	\N	\N	error	2025-11-04 03:42:56.093899+00
35	26	17	t	0.00	0.00	\N	\N	\N	error	2025-11-04 03:42:58.623817+00
36	26	18	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:42:58.746932+00
37	27	8	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:42:59.673864+00
38	27	11	t	0.00	0.00	\N	\N	\N	warning	2025-11-04 03:42:59.96884+00
39	27	10	t	\N	0.00	\N	\N	\N	warning	2025-11-04 03:43:00.041849+00
40	28	12	t	14.00	14.00	0.00	\N	\N	error	2025-11-04 03:43:02.979463+00
41	8	1	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:50:37.550918+00
42	8	4	t	0.00	0.00	0.00	\N	\N	warning	2025-11-04 03:50:37.628834+00
43	4	1	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:50:38.329024+00
44	4	4	t	0.00	0.00	0.00	\N	\N	warning	2025-11-04 03:50:38.524141+00
45	11	1	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:50:39.434499+00
46	11	4	t	0.00	0.00	0.00	\N	\N	warning	2025-11-04 03:50:39.713835+00
47	1	1	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:50:40.507145+00
48	1	4	t	0.00	0.00	0.00	\N	\N	warning	2025-11-04 03:50:40.568876+00
49	13	1	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:50:41.160158+00
50	13	4	t	0.00	0.00	0.00	\N	\N	warning	2025-11-04 03:50:41.266339+00
51	16	1	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:50:43.312513+00
52	16	4	t	0.00	0.00	0.00	\N	\N	warning	2025-11-04 03:50:43.372741+00
53	20	1	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:50:45.124835+00
54	20	4	t	0.00	0.00	0.00	\N	\N	warning	2025-11-04 03:50:45.208479+00
55	23	1	t	0.00	0.00	0.00	0.0000	\N	error	2025-11-04 03:50:45.839373+00
56	23	4	t	0.00	0.00	0.00	\N	\N	warning	2025-11-04 03:50:45.874815+00
\.


--
-- Data for Name: validation_rules; Type: TABLE DATA; Schema: public; Owner: reims
--

COPY public.validation_rules (id, rule_name, rule_description, document_type, rule_type, rule_formula, error_message, severity, is_active, created_at) FROM stdin;
1	balance_sheet_equation	Balance Sheet Equation: Assets = Liabilities + Equity	balance_sheet	balance_check	total_assets = total_liabilities + total_equity	Assets must equal Liabilities plus Equity	error	t	2025-11-04 03:39:00.207275+00
2	balance_sheet_current_assets	Current Assets sum correctly	balance_sheet	sum_check	sum(current_asset_accounts) = total_current_assets	Sum of current asset accounts doesn't match total	warning	t	2025-11-04 03:39:00.207275+00
3	balance_sheet_fixed_assets	Fixed Assets sum correctly	balance_sheet	sum_check	sum(fixed_asset_accounts) = total_fixed_assets	Sum of fixed asset accounts doesn't match total	warning	t	2025-11-04 03:39:00.207275+00
4	balance_sheet_no_negative_cash	Cash accounts should not be negative	balance_sheet	range_check	cash >= 0	Cash balance is negative	warning	t	2025-11-04 03:39:00.207275+00
5	balance_sheet_no_negative_equity	Total Equity should not be negative	balance_sheet	range_check	total_equity >= 0	Total Equity is negative (property may be underwater)	warning	t	2025-11-04 03:39:00.207275+00
6	income_statement_total_revenue	Revenue accounts sum to Total Revenue	income_statement	sum_check	sum(revenue_accounts) = total_revenue	Sum of revenue accounts doesn't match total revenue	error	t	2025-11-04 03:39:00.229564+00
7	income_statement_total_expenses	Expense accounts sum to Total Expenses	income_statement	sum_check	sum(expense_accounts) = total_expenses	Sum of expense accounts doesn't match total expenses	error	t	2025-11-04 03:39:00.229564+00
8	income_statement_net_income	Net Income = Total Revenue - Total Expenses	income_statement	balance_check	net_income = total_revenue - total_expenses	Net Income calculation is incorrect	error	t	2025-11-04 03:39:00.229564+00
9	income_statement_percentages	Period and YTD percentages should be reasonable	income_statement	range_check	-100 <= percentage <= 200	Percentage values are out of reasonable range	warning	t	2025-11-04 03:39:00.229564+00
10	income_statement_ytd_consistency	YTD amounts should be >= Period amounts	income_statement	range_check	ytd_amount >= period_amount	YTD amount is less than Period amount	warning	t	2025-11-04 03:39:00.229564+00
11	income_statement_no_negative_revenue	Revenue accounts should not be negative	income_statement	range_check	revenue >= 0	Revenue account has negative amount	warning	t	2025-11-04 03:39:00.229564+00
12	cash_flow_categories_sum	Operating + Investing + Financing = Net Change in Cash	cash_flow	balance_check	operating + investing + financing = net_change	Cash flow categories don't sum to net change	error	t	2025-11-04 03:39:00.240625+00
13	cash_flow_beginning_ending	Beginning Cash + Net Change = Ending Cash	cash_flow	balance_check	beginning_cash + net_change = ending_cash	Beginning + Net Change doesn't equal Ending Cash	error	t	2025-11-04 03:39:00.240625+00
14	cash_flow_cross_check_balance_sheet	Ending Cash (CF) should match Cash (BS)	cash_flow	cross_statement_check	ending_cash_cf = cash_bs	Ending Cash on Cash Flow doesn't match Cash on Balance Sheet	warning	t	2025-11-04 03:39:00.240625+00
15	rent_roll_occupancy_rate	Occupancy rate should be between 0-100%	rent_roll	range_check	0 <= occupancy_rate <= 100	Occupancy rate is out of valid range (0-100%)	error	t	2025-11-04 03:39:00.252027+00
16	rent_roll_total_rent	Sum of tenant rents should match total	rent_roll	sum_check	sum(monthly_rent) = total_monthly_rent	Sum of individual tenant rents doesn't match total	warning	t	2025-11-04 03:39:00.252027+00
17	rent_roll_no_duplicate_units	Each unit should appear only once	rent_roll	uniqueness_check	unit_number unique per period	Duplicate unit numbers found in rent roll	error	t	2025-11-04 03:39:00.252027+00
18	rent_roll_valid_lease_dates	Lease start date must be before end date	rent_roll	date_check	lease_start_date < lease_end_date	Lease start date is not before end date	warning	t	2025-11-04 03:39:00.252027+00
19	cross_net_income_consistency	Net Income should be consistent across Income Statement and Cash Flow	cross_statement	cross_statement_check	net_income_is = net_income_cf	Net Income differs between Income Statement and Cash Flow	warning	t	2025-11-04 03:39:00.262754+00
20	cross_cash_consistency	Cash balance should match across Balance Sheet and Cash Flow	cross_statement	cross_statement_check	cash_bs = ending_cash_cf	Cash balance differs between Balance Sheet and Cash Flow	warning	t	2025-11-04 03:39:00.262754+00
\.


--
-- Name: audit_trail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.audit_trail_id_seq', 1, false);


--
-- Name: balance_sheet_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.balance_sheet_data_id_seq', 62, true);


--
-- Name: cash_flow_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.cash_flow_data_id_seq', 16, true);


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.chart_of_accounts_id_seq', 139, true);


--
-- Name: document_uploads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.document_uploads_id_seq', 28, true);


--
-- Name: extraction_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.extraction_logs_id_seq', 46, true);


--
-- Name: extraction_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.extraction_templates_id_seq', 1, false);


--
-- Name: financial_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.financial_metrics_id_seq', 11, true);


--
-- Name: financial_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.financial_periods_id_seq', 12, true);


--
-- Name: income_statement_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.income_statement_data_id_seq', 4, true);


--
-- Name: properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.properties_id_seq', 5, true);


--
-- Name: rent_roll_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.rent_roll_data_id_seq', 124, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: validation_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.validation_results_id_seq', 56, true);


--
-- Name: validation_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: reims
--

SELECT pg_catalog.setval('public.validation_rules_id_seq', 20, true);


--
-- Name: audit_trail audit_trail_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_pkey PRIMARY KEY (id);


--
-- Name: balance_sheet_data balance_sheet_data_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_pkey PRIMARY KEY (id);


--
-- Name: cash_flow_data cash_flow_data_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_pkey PRIMARY KEY (id);


--
-- Name: chart_of_accounts chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);


--
-- Name: document_uploads document_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT document_uploads_pkey PRIMARY KEY (id);


--
-- Name: extraction_logs extraction_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.extraction_logs
    ADD CONSTRAINT extraction_logs_pkey PRIMARY KEY (id);


--
-- Name: extraction_templates extraction_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.extraction_templates
    ADD CONSTRAINT extraction_templates_pkey PRIMARY KEY (id);


--
-- Name: extraction_templates extraction_templates_template_name_key; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.extraction_templates
    ADD CONSTRAINT extraction_templates_template_name_key UNIQUE (template_name);


--
-- Name: financial_metrics financial_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT financial_metrics_pkey PRIMARY KEY (id);


--
-- Name: financial_periods financial_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT financial_periods_pkey PRIMARY KEY (id);


--
-- Name: income_statement_data income_statement_data_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: rent_roll_data rent_roll_data_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT rent_roll_data_pkey PRIMARY KEY (id);


--
-- Name: balance_sheet_data uq_bs_property_period_account; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT uq_bs_property_period_account UNIQUE (property_id, period_id, account_code);


--
-- Name: cash_flow_data uq_cf_property_period_account; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT uq_cf_property_period_account UNIQUE (property_id, period_id, account_code);


--
-- Name: income_statement_data uq_is_property_period_account; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT uq_is_property_period_account UNIQUE (property_id, period_id, account_code);


--
-- Name: financial_metrics uq_metrics_property_period; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT uq_metrics_property_period UNIQUE (property_id, period_id);


--
-- Name: financial_periods uq_property_period; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT uq_property_period UNIQUE (property_id, period_year, period_month);


--
-- Name: document_uploads uq_property_period_doctype_version; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT uq_property_period_doctype_version UNIQUE (property_id, period_id, document_type, version);


--
-- Name: rent_roll_data uq_rr_property_period_unit; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT uq_rr_property_period_unit UNIQUE (property_id, period_id, unit_number);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: validation_results validation_results_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_results
    ADD CONSTRAINT validation_results_pkey PRIMARY KEY (id);


--
-- Name: validation_rules validation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_rules
    ADD CONSTRAINT validation_rules_pkey PRIMARY KEY (id);


--
-- Name: validation_rules validation_rules_rule_name_key; Type: CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_rules
    ADD CONSTRAINT validation_rules_rule_name_key UNIQUE (rule_name);


--
-- Name: ix_audit_trail_changed_at; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_audit_trail_changed_at ON public.audit_trail USING btree (changed_at);


--
-- Name: ix_audit_trail_changed_by; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_audit_trail_changed_by ON public.audit_trail USING btree (changed_by);


--
-- Name: ix_audit_trail_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_audit_trail_id ON public.audit_trail USING btree (id);


--
-- Name: ix_audit_trail_record_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_audit_trail_record_id ON public.audit_trail USING btree (record_id);


--
-- Name: ix_audit_trail_table_name; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_audit_trail_table_name ON public.audit_trail USING btree (table_name);


--
-- Name: ix_balance_sheet_data_account_code; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_balance_sheet_data_account_code ON public.balance_sheet_data USING btree (account_code);


--
-- Name: ix_balance_sheet_data_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_balance_sheet_data_id ON public.balance_sheet_data USING btree (id);


--
-- Name: ix_balance_sheet_data_needs_review; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_balance_sheet_data_needs_review ON public.balance_sheet_data USING btree (needs_review);


--
-- Name: ix_balance_sheet_data_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_balance_sheet_data_period_id ON public.balance_sheet_data USING btree (period_id);


--
-- Name: ix_balance_sheet_data_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_balance_sheet_data_property_id ON public.balance_sheet_data USING btree (property_id);


--
-- Name: ix_cash_flow_data_cash_flow_category; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_cash_flow_data_cash_flow_category ON public.cash_flow_data USING btree (cash_flow_category);


--
-- Name: ix_cash_flow_data_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_cash_flow_data_id ON public.cash_flow_data USING btree (id);


--
-- Name: ix_cash_flow_data_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_cash_flow_data_period_id ON public.cash_flow_data USING btree (period_id);


--
-- Name: ix_cash_flow_data_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_cash_flow_data_property_id ON public.cash_flow_data USING btree (property_id);


--
-- Name: ix_chart_of_accounts_account_code; Type: INDEX; Schema: public; Owner: reims
--

CREATE UNIQUE INDEX ix_chart_of_accounts_account_code ON public.chart_of_accounts USING btree (account_code);


--
-- Name: ix_chart_of_accounts_account_type; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_chart_of_accounts_account_type ON public.chart_of_accounts USING btree (account_type);


--
-- Name: ix_chart_of_accounts_category; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_chart_of_accounts_category ON public.chart_of_accounts USING btree (category);


--
-- Name: ix_chart_of_accounts_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_chart_of_accounts_id ON public.chart_of_accounts USING btree (id);


--
-- Name: ix_document_uploads_document_type; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_document_uploads_document_type ON public.document_uploads USING btree (document_type);


--
-- Name: ix_document_uploads_extraction_status; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_document_uploads_extraction_status ON public.document_uploads USING btree (extraction_status);


--
-- Name: ix_document_uploads_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_document_uploads_id ON public.document_uploads USING btree (id);


--
-- Name: ix_document_uploads_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_document_uploads_period_id ON public.document_uploads USING btree (period_id);


--
-- Name: ix_document_uploads_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_document_uploads_property_id ON public.document_uploads USING btree (property_id);


--
-- Name: ix_extraction_logs_file_hash; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_extraction_logs_file_hash ON public.extraction_logs USING btree (file_hash);


--
-- Name: ix_extraction_logs_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_extraction_logs_id ON public.extraction_logs USING btree (id);


--
-- Name: ix_extraction_templates_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_extraction_templates_id ON public.extraction_templates USING btree (id);


--
-- Name: ix_financial_metrics_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_metrics_id ON public.financial_metrics USING btree (id);


--
-- Name: ix_financial_metrics_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_metrics_period_id ON public.financial_metrics USING btree (period_id);


--
-- Name: ix_financial_metrics_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_metrics_property_id ON public.financial_metrics USING btree (property_id);


--
-- Name: ix_financial_periods_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_periods_id ON public.financial_periods USING btree (id);


--
-- Name: ix_financial_periods_period_year; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_periods_period_year ON public.financial_periods USING btree (period_year);


--
-- Name: ix_financial_periods_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_financial_periods_property_id ON public.financial_periods USING btree (property_id);


--
-- Name: ix_income_statement_data_account_code; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_income_statement_data_account_code ON public.income_statement_data USING btree (account_code);


--
-- Name: ix_income_statement_data_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_income_statement_data_id ON public.income_statement_data USING btree (id);


--
-- Name: ix_income_statement_data_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_income_statement_data_period_id ON public.income_statement_data USING btree (period_id);


--
-- Name: ix_income_statement_data_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_income_statement_data_property_id ON public.income_statement_data USING btree (property_id);


--
-- Name: ix_properties_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_properties_id ON public.properties USING btree (id);


--
-- Name: ix_properties_property_code; Type: INDEX; Schema: public; Owner: reims
--

CREATE UNIQUE INDEX ix_properties_property_code ON public.properties USING btree (property_code);


--
-- Name: ix_properties_status; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_properties_status ON public.properties USING btree (status);


--
-- Name: ix_rent_roll_data_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_id ON public.rent_roll_data USING btree (id);


--
-- Name: ix_rent_roll_data_lease_end_date; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_lease_end_date ON public.rent_roll_data USING btree (lease_end_date);


--
-- Name: ix_rent_roll_data_occupancy_status; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_occupancy_status ON public.rent_roll_data USING btree (occupancy_status);


--
-- Name: ix_rent_roll_data_period_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_period_id ON public.rent_roll_data USING btree (period_id);


--
-- Name: ix_rent_roll_data_property_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_property_id ON public.rent_roll_data USING btree (property_id);


--
-- Name: ix_rent_roll_data_tenant_name; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_rent_roll_data_tenant_name ON public.rent_roll_data USING btree (tenant_name);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: reims
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: reims
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_validation_results_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_validation_results_id ON public.validation_results USING btree (id);


--
-- Name: ix_validation_results_passed; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_validation_results_passed ON public.validation_results USING btree (passed);


--
-- Name: ix_validation_results_upload_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_validation_results_upload_id ON public.validation_results USING btree (upload_id);


--
-- Name: ix_validation_rules_id; Type: INDEX; Schema: public; Owner: reims
--

CREATE INDEX ix_validation_rules_id ON public.validation_rules USING btree (id);


--
-- Name: audit_trail audit_trail_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- Name: balance_sheet_data balance_sheet_data_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: balance_sheet_data balance_sheet_data_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: balance_sheet_data balance_sheet_data_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: balance_sheet_data balance_sheet_data_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: balance_sheet_data balance_sheet_data_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.balance_sheet_data
    ADD CONSTRAINT balance_sheet_data_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.document_uploads(id) ON DELETE SET NULL;


--
-- Name: cash_flow_data cash_flow_data_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: cash_flow_data cash_flow_data_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: cash_flow_data cash_flow_data_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: cash_flow_data cash_flow_data_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: cash_flow_data cash_flow_data_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.cash_flow_data
    ADD CONSTRAINT cash_flow_data_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.document_uploads(id) ON DELETE SET NULL;


--
-- Name: document_uploads document_uploads_extraction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT document_uploads_extraction_id_fkey FOREIGN KEY (extraction_id) REFERENCES public.extraction_logs(id);


--
-- Name: document_uploads document_uploads_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT document_uploads_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: document_uploads document_uploads_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT document_uploads_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: document_uploads document_uploads_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.document_uploads
    ADD CONSTRAINT document_uploads_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: financial_metrics financial_metrics_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT financial_metrics_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: financial_metrics financial_metrics_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT financial_metrics_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: financial_periods financial_periods_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT financial_periods_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id);


--
-- Name: financial_periods financial_periods_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT financial_periods_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: income_statement_data income_statement_data_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: income_statement_data income_statement_data_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: income_statement_data income_statement_data_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: income_statement_data income_statement_data_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: income_statement_data income_statement_data_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.income_statement_data
    ADD CONSTRAINT income_statement_data_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.document_uploads(id) ON DELETE SET NULL;


--
-- Name: properties properties_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: rent_roll_data rent_roll_data_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT rent_roll_data_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id) ON DELETE CASCADE;


--
-- Name: rent_roll_data rent_roll_data_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT rent_roll_data_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: rent_roll_data rent_roll_data_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT rent_roll_data_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: rent_roll_data rent_roll_data_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.rent_roll_data
    ADD CONSTRAINT rent_roll_data_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.document_uploads(id) ON DELETE SET NULL;


--
-- Name: validation_results validation_results_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_results
    ADD CONSTRAINT validation_results_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.validation_rules(id);


--
-- Name: validation_results validation_results_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: reims
--

ALTER TABLE ONLY public.validation_results
    ADD CONSTRAINT validation_results_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.document_uploads(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict hfcBwGPF36M2jOwZPcOcJYZAuOWjab5cCVJ3wkuUCUrroJgRPXLBPxpPtrXDCbl

